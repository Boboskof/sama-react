import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import appointmentService from "../../_services/appointment.service";
import patientService from "../../_services/patient.service";
import documentService from "../../_services/document.service";
import { communicationService } from "../../_services/communication.service";
import userService from "../../_services/user.service";
import stagiaireNoteService from "../../_services/stagiaire-note.service";
import LoadingSpinner from "../../components/LoadingSpinner";
import SearchBar from "../../components/SearchBar";
import ErrorMessage from "../../components/ErrorMessage";
import NotesList from "../../components/NotesList";
import { useSearch } from "../../hooks/useSearch";
import { useTodayAppointments, useAppointmentStats } from "../../hooks/useAppointments";

const Dashboard = () => {
  // États principaux
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // React Query hooks pour les rendez-vous
  const { 
    data: todayAppointmentsData = [], 
    isLoading: appointmentsLoading, 
    error: appointmentsError 
  } = useTodayAppointments();
  
  const { 
    data: appointmentStatsData, 
    isLoading: statsLoading 
  } = useAppointmentStats();
  // Les rappels RDV sont désormais gérés par une commande cron côté serveur.
  // Laisser la possibilité de les activer côté front via variable d'env si besoin ponctuel.
  const ENABLE_FRONT_REMINDERS = (import.meta && import.meta.env ? import.meta.env.VITE_ENABLE_FRONT_REMINDERS : undefined) === 'true';
  const DISABLE_NOISY_FETCH = false; // tout réactivé
  
  // États des données
  // Note: todayAppointments est maintenant géré par React Query (useTodayAppointments)
  const [upcomingAppointments, setUpcomingAppointments] = useState([]);
  
  const [recentPatients, setRecentPatients] = useState([]);
  const [recentDocuments, setRecentDocuments] = useState([]);
  const [recentCommunications, setRecentCommunications] = useState([]);
  const [communicationStats, setCommunicationStats] = useState({});
  const [coverageAlerts, setCoverageAlerts] = useState({ manquantes: [], expirees: [] });
  const [stagiairePatientsStatus, setStagiairePatientsStatus] = useState({ meTotal: 0, totalStagiaires: 0 });
  // RDV des patients du stagiaire
  const [myPatientsAppointments, setMyPatientsAppointments] = useState([]);
  const [rdvPage, setRdvPage] = useState(1);
  const RDV_PAGE_SIZE = 10;
  // Notes du formateur
  const [notes, setNotes] = useState([]);
  const [notesLoading, setNotesLoading] = useState(false);

  // Hook de recherche globale
  const { 
    query, 
    setQuery, 
    results: searchResults, 
    loading: searchLoading, 
    error: searchError, 
    total: searchTotal 
  } = useSearch(null, { 
    limit: 10
  });
  const [stats, setStats] = useState({
    patientsCreatedToday: 0,
    rendezVousToday: 0,
    documentsUploadedToday: 0,
    couverturesCheckedToday: 0,
    communicationsSentToday: 0,
    productivityScore: 0,
    totalPatientsCreated: 0,
    patientsThisWeek: 0,
    incompleteDossiers: 0,
    documentsUploaded: 0,
    storageUsed: 0,
    documentsPending: 0,
    couverturesChecked: 0,
    couverturesValid: 0,
    couverturesExpired: 0,
    couverturesToCheck: 0,
    messagesSent: 0,
    messagesRead: 0,
    readRate: 0
  });

  // Chargement des données du dashboard
  const loadDashboardData = async () => {
    try {
      setLoading(true);
      // Charger l'utilisateur connecté (fallback localStorage)
      const storedUser = userService.getUser?.() || null;
      if (storedUser) {
        setUser(storedUser);
      }
      const currentUser = await userService.getCurrentUser().catch(() => storedUser || null);
      setUser(currentUser);

      if (!currentUser) {
        return;
      }

      // Charger les données essentielles (réduire le bruit réseau)
      // Note: Les rendez-vous d'aujourd'hui et les stats sont maintenant gérés par React Query
      const [patientsList, commSummary, alerts, totalPatientsCount, stagiaireStatus] = await Promise.all([
        patientService.getAllPatients().catch(() => []),
        communicationService.getStatusSummary().catch(() => ({ total_envoyees: 0, envoyees_aujourdhui: 0, echecs: 0 })),
        patientService.getCoverageAlerts().catch(() => ({ manquantes: [], expirees: [] })),
        patientService.countAllPatients().catch(() => 0),
        patientService.getStagiairePatientsStatus().catch(() => ({}))
      ]);
      const upcomingList = await appointmentService.getUpcomingAppointments().catch(() => []);
      const documentsList = await documentService.getDocuments({ limit: 10 }).catch(() => []);
      const communicationsList = await communicationService.getCommunications({ limit: 10, statut: ['ENVOYE'], creePar: currentUser.id }).catch(() => []);
      
      // Charger les notes du formateur pour ce stagiaire (utilise /api/me/notes)
      setNotesLoading(true);
      try {
        const notesList = await stagiaireNoteService.getMyNotes('DESC');
        setNotes(Array.isArray(notesList) ? notesList : []);
      } catch (err) {
        console.error('Erreur chargement notes:', err);
        setNotes([]);
      } finally {
        setNotesLoading(false);
      }

      // Mettre à jour les états (les rendez-vous d'aujourd'hui sont maintenant gérés par React Query)
      // Synchroniser avec les données React Query pour le tri
      // Exclure les RDV du jour de la liste "À venir"
      const todayIso = new Date();
      todayIso.setHours(0,0,0,0);
      const upcomingFiltered = (Array.isArray(upcomingList) ? upcomingList : []).filter(r => {
        const s = r.startAt || r.start_at || r.appointmentTime;
        if (!s) return false;
        const d = new Date(s);
        if (isNaN(d.getTime())) return true;
        const dd = new Date(d);
        dd.setHours(0,0,0,0);
        return dd.getTime() !== todayIso.getTime();
      });
      setUpcomingAppointments(upcomingFiltered);
      setRecentPatients(Array.isArray(patientsList) ? patientsList.slice(0, 5) : []);
      setRecentDocuments(Array.isArray(documentsList) ? documentsList.slice(0, 5) : []);
      setRecentCommunications(Array.isArray(communicationsList) ? communicationsList.slice(0, 5) : []);
      setCoverageAlerts({
        manquantes: Array.isArray(alerts?.manquantes) ? alerts.manquantes : [],
        expirees: Array.isArray(alerts?.expirees) ? alerts.expirees : [],
      });
      setStagiairePatientsStatus({
        meTotal: Number(stagiaireStatus?.me?.total || 0),
        totalStagiaires: Number(stagiaireStatus?.total_stagiaires || (Array.isArray(stagiaireStatus?.items) ? stagiaireStatus.items.length : 0))
      });

      // Charger les statistiques de communications (temporairement désactivé)
      // TODO: Réactiver quand l'endpoint /communications/statistics sera disponible
      setCommunicationStats({});

      // Construire la liste des RDV de tous les patients du stagiaire (prochains d'abord)
      try {
        const patientIds = new Set((Array.isArray(patientsList) ? patientsList : []).map(p => String(p.id)));
        const allUpcoming = Array.isArray(upcomingList) ? upcomingList : [];
        const mine = allUpcoming.filter(r => {
          const pid = r?.patient?.id || r?.patient_id || r?.patientId;
          return pid && patientIds.has(String(pid));
        }).sort((a, b) => new Date(a.startAt || a.start_at || a.appointmentTime || 0) - new Date(b.startAt || b.start_at || b.appointmentTime || 0));
        // Enrichir avec le médecin si manquant (fetch détails sur un petit lot)
        const needDoctor = mine.filter(r => !r.medecin && !r.doctor).slice(0, 20);
        if (needDoctor.length > 0) {
          const details = await Promise.allSettled(needDoctor.map(r => appointmentService.getOneAppointment(r.id).catch(() => null)));
          const byId = new Map();
          details.forEach((res, idx) => {
            const orig = needDoctor[idx];
            if (res.status === 'fulfilled' && res.value) byId.set(orig.id, res.value);
          });
          const enriched = mine.map(r => {
            const d = byId.get(r.id);
            if (!d) return r;
            return { ...r, medecin: d.medecin || d.doctor || r.medecin || r.doctor, statut: d.statut || r.statut || d.status || r.status };
          });
          setMyPatientsAppointments(enriched);
        } else {
          setMyPatientsAppointments(mine);
        }
      } catch {}

      // Calculer les statistiques
      const today = new Date().toISOString().split('T')[0];
      const thisWeek = new Date();
      thisWeek.setDate(thisWeek.getDate() - 7);

      const patientsCreatedToday = Array.isArray(patientsList) ? 
        patientsList.filter(p => p.createdAt && p.createdAt.startsWith(today)).length : 0;
      
      const documentsUploadedToday = Array.isArray(documentsList) ? 
        documentsList.filter(d => d.uploadedAt && d.uploadedAt.startsWith(today)).length : 0;
      
      // Utiliser l'endpoint agrégé pour un comptage fiable
      const communicationsSentToday = Number(commSummary?.envoyees_aujourdhui ?? 0);

      // Couvertures mutuelles (via endpoint de stats dédié)
      let covChecked = 0;
      let covValid = 0;
      let covExpired = 0;
      let covToCheck = 0;
      try {
        const s = await patientService.getCoverageStatus();
        covValid = s.valides;
        covExpired = s.expirees;
        covToCheck = s.manquantes;
        covChecked = s.total; // total en base; utilisé ici comme volume global
      } catch {
        // Fallback silencieux si l'endpoint n'est pas dispo
      }

      // Utiliser les données React Query si disponibles, sinon utiliser les données chargées
      const rdvCount = appointmentStatsData?.today?.total ?? (Array.isArray(todayAppointmentsData) ? todayAppointmentsData.length : 0);
      
      setStats({
        patientsCreatedToday,
        rendezVousToday: Number(rdvCount),
        documentsUploadedToday,
        couverturesCheckedToday: covChecked,
        communicationsSentToday,
        productivityScore: Math.min(100, (patientsCreatedToday + documentsUploadedToday) * 10),
        totalPatientsCreated: Number((stagiaireStatus?.me?.total ?? 0) || totalPatientsCount || 0),
        patientsThisWeek: Array.isArray(patientsList) ? 
          patientsList.filter(p => p.createdAt && new Date(p.createdAt) >= thisWeek).length : 0,
        incompleteDossiers: 0,
        documentsUploaded: Array.isArray(documentsList) ? documentsList.length : 0,
        storageUsed: 0,
        documentsPending: 0,
        couverturesChecked: covChecked,
        couverturesValid: covValid,
        couverturesExpired: covExpired,
        couverturesToCheck: covToCheck,
        messagesSent: Number(commSummary?.total_envoyees ?? 0),
        messagesRead: 0,
        readRate: 0
      });

    } catch (error) {
      console.error("Erreur lors du chargement des données:", error);
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  // Gérer les erreurs React Query
  useEffect(() => {
    if (appointmentsError) {
      setError(appointmentsError);
    }
  }, [appointmentsError]);

  // Trier les rendez-vous d'aujourd'hui par horaire (du plus tôt au plus tard)
  const sortedTodayAppointments = useMemo(() => {
    // Utiliser les données React Query directement
    if (!Array.isArray(todayAppointmentsData) || todayAppointmentsData.length === 0) {
      return [];
    }
    
    // Créer une copie pour ne pas muter l'original
    const appointments = [...todayAppointmentsData];
    
    return appointments.sort((a, b) => {
      const startA = a.startAt || a.start_at || a.appointmentTime;
      const startB = b.startAt || b.start_at || b.appointmentTime;
      
      if (!startA && !startB) return 0;
      if (!startA) return 1; // Les rendez-vous sans heure à la fin
      if (!startB) return -1;
      
      const dateA = new Date(startA);
      const dateB = new Date(startB);
      
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      
      return dateA.getTime() - dateB.getTime(); // Tri croissant (du plus tôt au plus tard)
    });
  }, [todayAppointmentsData]);

  // Auto envoi des rappels RDV (désactivé par défaut, remplacer VITE_ENABLE_FRONT_REMINDERS=true pour activer)
  useEffect(() => {
    if (!ENABLE_FRONT_REMINDERS) return;
    let cancelled = false;
    const run = async () => {
      try {
        // récupérer les prochains RDV (prochaine quinzaine)
        const upcoming = await appointmentService.getUpcomingAppointments().catch(() => []);
        const now = Date.now();
        const sent = JSON.parse(localStorage.getItem('autoRdvReminders') || '{}');
        const markSent = (id, windowTag) => {
          const next = { ...(sent || {}) };
          next[id] = { ...(next[id] || {}) , [windowTag]: now };
          localStorage.setItem('autoRdvReminders', JSON.stringify(next));
        };
        for (const rdv of upcoming || []) {
          const id = rdv.id;
          const startRaw = rdv.startAt || rdv.start_at || rdv.appointmentTime;
          if (!id || !startRaw) continue;
          const t = new Date(startRaw).getTime();
          if (isNaN(t)) continue;
          const msTo = t - now;
          const hoursTo = msTo / 3_600_000;
          const record = sent && sent[id] ? sent[id] : {};
          // fenêtre d’envoi: ±1h autour de 168h (7 jours) et 24h
          const inWindow7d = hoursTo <= 168 + 1 && hoursTo >= 168 - 1;
          const inWindow24h = hoursTo <= 24 + 1 && hoursTo >= 24 - 1;
          if (inWindow7d && !record['7d']) {
            try { await communicationService.sendRappelRendezVous(id, { canal: 'EMAIL_SMS' }); } catch {}
            markSent(id, '7d');
          }
          if (inWindow24h && !record['24h']) {
            try { await communicationService.sendRappelRendezVous(id, { canal: 'EMAIL_SMS' }); } catch {}
            markSent(id, '24h');
          }
          if (cancelled) break;
        }
      } catch {}
    };
    run();
    return () => { cancelled = true; };
  }, [ENABLE_FRONT_REMINDERS]);

  const formatTime = (timeString) => {
    if (!timeString) return "";
    const date = new Date(timeString);
    return date.toLocaleTimeString("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  // Résolution robuste du nom patient pour les documents récents
  const getPatientNameFromDoc = (doc) => {
    const p = doc?.patient;
    if (p && typeof p === 'object') {
      const fn = p.prenom || p.firstName || '';
      const ln = p.nom || p.lastName || '';
      const name = `${fn} ${ln}`.trim();
      if (name) return name;
    }
    const pid = doc?.patient_id || doc?.patientId || (typeof p === 'string' ? p.split('/')?.pop() : null);
    if (pid) {
      const all = Array.isArray(recentPatients) ? recentPatients : [];
      const found = all.find(x => String(x.id) === String(pid));
      if (found) {
        const name = `${found.prenom || ''} ${found.nom || ''}`.trim();
        if (name) return name;
      }
    }
    return 'Patient inconnu';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner message="Chargement des données..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      {/* Titre centré avec icône et description */}
      <div className="text-center py-6 mb-6">
        <div className="bg-blue-200 rounded-lg shadow p-6 max-w-xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-blue-600 text-2xl">dashboard</span>
            </div>
            <h1 className="text-2xl font-bold text-blue-800">Tableau de Bord</h1>
          </div>
          <p className="text-blue-700 text-sm">
            Vue d'ensemble de votre activité médicale
          </p>
        </div>
      </div>

      {/* En-tête personnalisé */}
      {/* Message d'erreur global */}
      {error && (
        <div className="mb-6">
          <ErrorMessage 
            message={error} 
            title="Erreur de chargement"
            dismissible={true}
            onDismiss={() => setError(null)}
          />
        </div>
      )}

      <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6 mb-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-green-600">
                {user?.prenom?.[0] || 'S'}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Bonjour {user?.prenom} {user?.nom}
              </h1>
              <p className="text-gray-600">Stagiaire - {user?.section || 'Formation médicale'}</p>
              <p className="text-sm text-gray-500">
                Dernière connexion : {formatDate(user?.lastLoginAt || new Date())}
              </p>
            </div>
          </div>
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex space-x-3">
              <Link to="/patients/nouveau" className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg hover:bg-orange-200 transition-colors shadow-md flex items-center gap-2">
                <span className="material-symbols-rounded">person_add</span>
                Nouveau patient
              </Link>
              <Link to="/appointments" className="bg-pink-100 text-pink-700 px-4 py-2 rounded-lg hover:bg-pink-200 transition-colors shadow-md flex items-center gap-2">
                <span className="material-symbols-rounded">event</span>
                Nouveau RDV
              </Link>
              <Link to="/documents" className="bg-green-100 text-green-700 px-4 py-2 rounded-lg hover:bg-green-200 transition-colors shadow-md flex items-center gap-2">
                <span className="material-symbols-rounded">upload_file</span>
                Upload document
              </Link>
              <Link
                to="/communications"
                className="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200 transition-colors shadow-md flex items-center gap-2"
              >
                <span className="material-symbols-rounded">chat</span>
                Nouvelle communication
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Métriques clés (KPIs) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-blue-600 text-2xl">groups</span>
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Patients créés</h3>
              <p className="text-2xl font-bold text-gray-900">{stats.patientsCreatedToday}</p>
              <p className="text-sm text-green-600">Aujourd'hui</p>
            </div>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-green-600 text-2xl">calendar_month</span>
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">RDV aujourd'hui</h3>
              <p className="text-2xl font-bold text-gray-900">{stats.rendezVousToday}</p>
              <p className="text-sm text-blue-600">Planifiés</p>
            </div>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-purple-600 text-2xl">description</span>
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Documents uploadés</h3>
              <p className="text-2xl font-bold text-gray-900">{stats.documentsUploadedToday}</p>
              <p className="text-sm text-purple-600">Aujourd'hui</p>
            </div>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-orange-600 text-2xl">health_and_safety</span>
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Couvertures enregistrées</h3>
              <p className="text-2xl font-bold text-gray-900">{stats.couverturesCheckedToday}</p>
              <p className="text-sm text-orange-600">Total</p>
            </div>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-pink-600 text-2xl">chat_bubble</span>
            </div>
            <div className="ml-4 flex flex-col items-start justify-center">
              <h3 className="text-sm font-medium text-gray-500">Communications</h3>
              <p className="text-sm text-transparent select-none">&nbsp;</p>
              <p className="text-2xl font-bold text-gray-900">{stats.communicationsSentToday}</p>
              <p className="text-sm text-pink-600">Envoyées</p>
            </div>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-indigo-600 text-2xl">trending_up</span>
            </div>
            <div className="ml-4 flex flex-col items-start justify-center">
              <h3 className="text-sm font-medium text-gray-500">Productivité</h3>
              <p className="text-sm text-transparent select-none">&nbsp;</p>
              <p className="text-2xl font-bold text-gray-900">{stats.productivityScore}%</p>
              <p className="text-sm text-indigo-600">Score</p>
            </div>
          </div>
        </div>

        {/* Patients par stagiaire */}
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-pink-600 text-2xl">badge</span>
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Patients (stagiaire)</h3>
              <p className="text-2xl font-bold text-gray-900">{stagiairePatientsStatus.meTotal}</p>
              {stagiairePatientsStatus.totalStagiaires > 0 && (
                <p className="text-sm text-gray-500">Stagiaires: {stagiairePatientsStatus.totalStagiaires}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Notes du formateur */}
      <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg border-l-4 border-indigo-400 mb-6">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <span className="material-symbols-rounded text-indigo-600">note</span>
              Notes du formateur
            </h2>
          </div>
        </div>
        <div className="p-6">
          <NotesList 
            notes={notes} 
            loading={notesLoading}
            canDelete={false}
          />
        </div>
      </div>

      {/* Statistiques détaillées des communications */}
      {Object.keys(communicationStats).length > 0 && (
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <span className="material-symbols-rounded text-purple-600">analytics</span>
            Statistiques des Communications
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {communicationStats.total && (
              <div className="bg-purple-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-600 font-medium">Total</p>
                    <p className="text-2xl font-bold text-purple-900">{communicationStats.total}</p>
                  </div>
                  <span className="material-symbols-rounded text-purple-600 text-2xl">chat_bubble</span>
                </div>
              </div>
            )}
            {communicationStats.byStatus && (
              Object.entries(communicationStats.byStatus).map(([status, count]) => (
                <div key={status} className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 font-medium capitalize">{status.toLowerCase()}</p>
                      <p className="text-2xl font-bold text-gray-900">{count}</p>
                    </div>
                    <span className="material-symbols-rounded text-gray-600 text-2xl">
                      {status === 'ENVOYE' ? 'check_circle' : 
                       status === 'EN_ATTENTE' ? 'schedule' : 
                       status === 'ECHEC' ? 'error' : 'edit'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Sections principales */}
      <div className="grid grid-cols-1 gap-6 mb-6">
        {/* Gestion des patients - Couleur orange comme la page patients */}
        <div className="bg-orange-50/90 backdrop-blur-sm rounded-lg shadow-lg border-l-4 border-orange-400">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <span className="material-symbols-rounded text-orange-600">groups</span>
                Gestion des patients
              </h2>
              <div className="flex space-x-2">
                <Link to="/patients/nouveau" className="bg-orange-600 text-white px-3 py-1 rounded text-sm hover:bg-orange-700 shadow-sm flex items-center gap-1">
                  <span className="material-symbols-rounded text-white text-base">person_add</span>
                  Nouveau
                </Link>
                <Link to="/patients" className="bg-slate-600 text-white px-3 py-1 rounded text-sm hover:bg-slate-700 shadow-sm flex items-center gap-1">
                  <span className="material-symbols-rounded text-white text-base">search</span>
                  Rechercher
                </Link>
              </div>
            </div>
          </div>
          <div className="p-6">
            {/* Statistiques patients */}
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{stats.totalPatientsCreated}</p>
                <p className="text-sm text-gray-500">Total créés</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{stats.patientsThisWeek}</p>
                <p className="text-sm text-gray-500">Cette semaine</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{stats.incompleteDossiers}</p>
                <p className="text-sm text-gray-500">Incomplets</p>
              </div>
            </div>

            {/* Patients récents */}
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-3">Patients récemment créés</h3>
              <div className="space-y-3">
                {recentPatients.map((patient, index) => (
                  <div key={patient.id || index} className="flex items-center justify-between p-3 rounded-lg shadow">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-green-600">
                          {patient.prenom?.[0] || 'P'}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {patient.prenom} {patient.nom}
                        </p>
                        <p className="text-xs text-gray-500">{patient.email}</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {patient.id ? (
                        <>
                          <Link to={`/patients/${patient.id}`} className="text-blue-600 hover:text-blue-800 text-xs">Voir</Link>
                          <Link to={`/patients/${patient.id}/modifier`} className="text-gray-600 hover:text-gray-800 text-xs">Modifier</Link>
                        </>
                      ) : (
                        <Link to="/patients" className="text-blue-600 hover:text-blue-800 text-xs">Ouvrir</Link>
                      )}
                    </div>
                  </div>
                ))}
                {recentPatients.length === 0 && (
                  <p className="text-gray-500 text-sm text-center py-4">Aucun patient récent</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Planning des rendez-vous - Couleur rose comme la page appointments */}
        <div className="bg-pink-50/90 backdrop-blur-sm rounded-lg shadow-lg border-l-4 border-pink-400">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <span className="material-symbols-rounded text-pink-600">calendar_month</span>
                Planning des rendez-vous
              </h2>
              <div className="flex space-x-2">
                <Link to="/appointments" className="bg-pink-600 text-white px-3 py-1 rounded text-sm hover:bg-pink-700 shadow-sm flex items-center gap-1">
                  <span className="material-symbols-rounded text-white text-base">event</span>
                  Aujourd'hui
                </Link>
                <Link to="/appointments" className="bg-slate-600 text-white px-3 py-1 rounded text-sm hover:bg-slate-700 shadow-sm flex items-center gap-1">
                  <span className="material-symbols-rounded text-white text-base">calendar_month</span>
                  Cette semaine
                </Link>
              </div>
            </div>
          </div>
          <div className="p-6">
            {/* Statistiques planning (seulement aujourd'hui) */}
            <div className="grid grid-cols-1 gap-4 mb-4">
              <div className="text-center p-3">
                <p className="text-2xl font-bold text-gray-900">{stats.rendezVousToday}</p>
                <p className="text-sm text-gray-500">Aujourd'hui</p>
              </div>
            </div>

            {/* Liste RDV du jour */}
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-3">Rendez-vous d'aujourd'hui</h3>
              {appointmentsLoading && (
                <div className="flex items-center justify-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-pink-500"></div>
                  <span className="ml-2 text-sm text-gray-600">Chargement...</span>
                </div>
              )}
              {!appointmentsLoading && (
              <div className="space-y-3">
                {sortedTodayAppointments.map((rdv, index) => {
                  const start = rdv.startAt || rdv.start_at || rdv.appointmentTime;
                  const med = rdv.medecin || rdv.doctor || {};
                  const medNomUpper = (med.nom || med.lastName || '').toUpperCase();
                  const medPrenom = med.prenom || med.firstName || '';
                  const spec = med?.specialite?.label || med?.specialite?.nom || med?.specialite || med?.specialty?.name || med?.specialty || '';
                  const sRaw = (rdv.statut || rdv.status || '').toString().toUpperCase();
                  const isPlan = sRaw.includes('PLAN');
                  const isConf = sRaw.includes('CONFIRM');
                  const isAbs = sRaw.includes('ABSEN');
                  const isAnn = sRaw.includes('ANNU');
                  const badgeCls = isConf
                    ? 'bg-green-100 text-green-800'
                    : isPlan
                      ? 'bg-blue-100 text-blue-800'
                      : isAbs
                        ? 'bg-purple-100 text-purple-800'
                        : isAnn
                          ? 'bg-red-100 text-red-800'
                          : 'bg-gray-100 text-gray-800';
                  const label = isConf ? 'Confirmé' : isPlan ? 'Planifié' : isAbs ? 'Absent' : isAnn ? 'Annulé' : 'Inconnu';
                  return (
                    <div key={rdv.id || index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="text-sm font-medium text-gray-900">
                          {formatTime(start)}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {rdv.patient?.prenom} {rdv.patient?.nom}
                          </p>
                          <p className="text-xs text-gray-500">
                            {rdv.motif}
                            {medNomUpper ? (
                              <> • Dr <span className="font-extrabold">{medNomUpper}</span> <span className="font-semibold">{medPrenom}</span>{spec ? ` — ${spec}` : ''}</>
                            ) : null}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${badgeCls}`}>{label}</span>
                      </div>
                    </div>
                  );
                })}
                {sortedTodayAppointments.length === 0 && !appointmentsLoading && (
                  <p className="text-gray-500 text-sm text-center py-4">Aucun rendez-vous aujourd'hui</p>
                )}
              </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Gestion des documents - Couleur verte comme la page documents */}
      <div className="bg-green-50/90 backdrop-blur-sm rounded-lg shadow-lg border-l-4 border-green-400 mb-6">
        <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <span className="material-symbols-rounded text-green-700">description</span>
                Gestion des documents
              </h2>
            <div className="flex space-x-2">
              <Link to="/documents" className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 shadow-sm flex items-center gap-1">
                <span className="material-symbols-rounded text-white text-base">upload_file</span>
                Upload document
              </Link>
              <Link to="/documents" className="bg-slate-600 text-white px-3 py-1 rounded text-sm hover:bg-slate-700 shadow-sm flex items-center gap-1">
                <span className="material-symbols-rounded text-white text-base">search</span>
                Rechercher
              </Link>
            </div>
          </div>
        </div>
        <div className="p-6">
          {/* Statistiques documents */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{stats.documentsUploaded}</p>
              <p className="text-sm text-gray-500">Documents uploadés</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{formatFileSize(stats.storageUsed)}</p>
              <p className="text-sm text-gray-500">Espace utilisé</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">{stats.documentsPending}</p>
              <p className="text-sm text-gray-500">En attente</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">4</p>
              <p className="text-sm text-gray-500">Types de documents</p>
            </div>
          </div>

          {/* Documents récents */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Documents récemment uploadés</h3>
            <div className="space-y-3">
              {recentDocuments.map((doc, index) => (
                <div key={doc.id || index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                      <span className="text-sm">📄</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {doc.originalName || doc.title || 'Document sans nom'}
                      </p>
                      <p className="text-xs text-gray-500">
                        Patient: {getPatientNameFromDoc(doc)}
                      </p>
                      <p className="text-xs text-gray-500">
                        Type: {doc.type || 'Inconnu'} • {formatDate(doc.uploadedAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Link to="/documents" className="text-blue-600 hover:text-blue-800 text-xs">Voir dans Documents</Link>
                  </div>
                </div>
              ))}
              {recentDocuments.length === 0 && (
                <p className="text-gray-500 text-sm text-center py-4">Aucun document récent</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Section "Prochains rendez-vous de mes patients" supprimée sur demande */}

      {/* Couvertures mutuelles - Couleur orange comme la page patients */}
      <div className="bg-orange-50/90 backdrop-blur-sm rounded-lg shadow-lg border-l-4 border-orange-400 mb-6">
        <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <span className="material-symbols-rounded text-orange-600">health_and_safety</span>
                Couvertures mutuelles
              </h2>
            </div>
        </div>
        <div className="p-6">
          {/* Statistiques couvertures: Valides / Expirées / Manquantes */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{stats.couverturesValid}</p>
              <p className="text-sm text-gray-500">Valides</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">{stats.couverturesExpired}</p>
              <p className="text-sm text-gray-500">Expirées</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-600">{stats.couverturesToCheck}</p>
              <p className="text-sm text-gray-500">Manquantes</p>
            </div>
          </div>

          {/* Alertes couvertures */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Alertes couvertures</h3>
            {/* Manquantes */}
            <div className="mb-4">
              <h4 className="text-sm font-semibold text-yellow-700 mb-2">Manquantes ({coverageAlerts.manquantes.length})</h4>
              {coverageAlerts.manquantes.length === 0 ? (
                <p className="text-xs text-gray-500">Aucune</p>
              ) : (
                <ul className="space-y-2">
                  {coverageAlerts.manquantes.slice(0, 5).map((it, idx) => (
                    <li key={idx} className="flex items-center justify-between text-sm bg-yellow-50 border border-yellow-200 rounded px-3 py-2">
                      <span>{it.patient?.prenom || ''} {it.patient?.nom || ''}</span>
                      {it.patient?.id && (
                        <Link to={`/patients/${it.patient.id}`} className="text-blue-600 hover:text-blue-800 text-xs">Ouvrir</Link>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            {/* Expirées */}
            <div>
              <h4 className="text-sm font-semibold text-red-700 mb-2">Expirées ({coverageAlerts.expirees.length})</h4>
              {coverageAlerts.expirees.length === 0 ? (
                <p className="text-xs text-gray-500">Aucune</p>
              ) : (
                <ul className="space-y-2">
                  {coverageAlerts.expirees.slice(0, 5).map((it, idx) => (
                    <li key={idx} className="text-sm bg-red-50 border border-red-200 rounded px-3 py-2">
                      <div className="flex items-center justify-between">
                        <span>{it.patient?.prenom || ''} {it.patient?.nom || ''}</span>
                        {it.patient?.id && (
                          <Link to={`/patients/${it.patient.id}`} className="text-blue-600 hover:text-blue-800 text-xs">Ouvrir</Link>
                        )}
                      </div>
                      <div className="text-xs text-gray-600 mt-1">
                        {it.mutuelle ? `Mutuelle: ${it.mutuelle}` : ''}
                        {it.numeroAdherent ? ` • Adhérent: ${it.numeroAdherent}` : ''}
                        {it.dateFin ? ` • Fin: ${new Date(it.dateFin).toLocaleDateString('fr-FR')}` : ''}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Communications - Couleur violette comme la page communications */}
      <div className="bg-purple-50/90 backdrop-blur-sm rounded-lg shadow-lg border-l-4 border-purple-400 mb-6">
        <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <span className="material-symbols-rounded text-pink-600">chat_bubble</span>
                Communications
              </h2>
              <div className="flex space-x-2">
                <Link to="/communications" className="bg-purple-600 text-white px-3 py-1 rounded text-sm hover:bg-purple-700 shadow-sm flex items-center gap-1">
                  <span className="material-symbols-rounded text-white text-base">add_comment</span>
                  Nouveau message
                </Link>
              </div>
            </div>
        </div>
        <div className="p-6">
          {/* Statistiques communications */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{stats.messagesSent}</p>
              <p className="text-sm text-gray-500">Messages envoyés</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{stats.messagesRead}</p>
              <p className="text-sm text-gray-500">Messages lus</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{stats.readRate}%</p>
              <p className="text-sm text-gray-500">Taux de lecture</p>
            </div>
          </div>

          {/* Communications récentes */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Communications récentes</h3>
            <div className="space-y-3">
              {recentCommunications.map((comm, index) => (
                <div key={comm.id || index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                      <span className="text-sm">💬</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {comm.sujet || 'Sans sujet'}
                      </p>
                      <p className="text-xs text-gray-500">
                        Patient: {comm.patient?.prenom || 'Inconnu'} {comm.patient?.nom || ''}
                      </p>
                      <p className="text-xs text-gray-500">
                        Type: {comm.type} • {formatDate(comm.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Link to="/communications" className="text-blue-600 hover:text-blue-800 text-xs">Voir dans Communications</Link>
                  </div>
                </div>
              ))}
              {recentCommunications.length === 0 && (
                <p className="text-gray-500 text-sm text-center py-4">Aucune communication récente</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Statistiques personnelles */}
      <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg">
        <div className="p-6 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <span className="material-symbols-rounded text-indigo-600">insights</span>
          Mes statistiques personnelles
        </h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Graphique d'activité */}
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-4">Activité quotidienne (7 derniers jours)</h3>
              <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center">
                <p className="text-gray-500 text-sm">Graphique d'activité à implémenter</p>
              </div>
            </div>

            {/* Objectifs */}
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-4">Mes objectifs</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Créer 10 patients cette semaine</p>
                    <p className="text-xs text-gray-500">Progression: {Math.min(100, (stats.patientsThisWeek / 10) * 100)}%</p>
                  </div>
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{ width: `${Math.min(100, (stats.patientsThisWeek / 10) * 100)}%` }}
                    ></div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Uploader 5 documents par jour</p>
                    <p className="text-xs text-gray-500">Progression: {Math.min(100, (stats.documentsUploadedToday / 5) * 100)}%</p>
                  </div>
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${Math.min(100, (stats.documentsUploadedToday / 5) * 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;