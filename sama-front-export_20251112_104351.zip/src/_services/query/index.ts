// Export centralisé de tous les mappers de requêtes
export * from './communications.query';
export * from './patients.query';
export * from './appointments.query';
export * from './documents.query';
export * from './audit.query';
export * from './statistics.query';
export * from './formateur.query';
