import React, { useState, useEffect, useCallback } from "react";
import userService from "../../_services/user.service";
import appointmentService from "../../_services/appointment.service";
import patientService from "../../_services/patient.service";
import medecinService from "../../_services/medecin.service";
// Recherche/filters retirés

// Exemple d'Appointments simplifié avec mappers
const Appointments = () => {
  // États principaux
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Référentiels
  const [patients, setPatients] = useState([]);
  const [medecins, setMedecins] = useState([]);
  const [selectedMedecinId, setSelectedMedecinId] = useState('');
  const [showDoctorPicker, setShowDoctorPicker] = useState(false);

  // Stats basiques
  const [stats, setStats] = useState({ total: 0, confirmes: 0, enAttente: 0, annules: 0, termines: 0, absents: 0 });
  // (Section RDV des patients retirée)

  // Style visuel + calendrier/agenda (clonés)
const HOURS_START = 8;
const HOURS_END = 18;
const SLOT_MINUTES = 30;
  const HAUTEUR_MIN_CARTE_CRENEAU = 64; // px, pour fusion visuelle des créneaux

  const toISODate = (d) => {
  const z = new Date(d);
  z.setHours(0, 0, 0, 0);
  const year = z.getFullYear();
  const month = String(z.getMonth() + 1).padStart(2, '0');
  const day = String(z.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Parse heures/minutes depuis formats back: "YYYY-MM-DD HH:mm:ss" ou ISO
  const extractHHmm = (dateLike) => {
    if (!dateLike) return '';
    if (typeof dateLike === 'string') {
      const s = dateLike;
      // 1) "YYYY-MM-DD HH:mm:ss"
      let m = s.match(/^(\d{4})-(\d{2})-(\d{2})\s(\d{2}):(\d{2})(?::\d{2})?$/);
      if (m) return `${m[4]}:${m[5]}`;
      // 2) ISO: "YYYY-MM-DDTHH:mm:ss"(+tz)
      m = s.match(/T(\d{2}):(\d{2})(?::\d{2})?/);
      if (m) return `${m[1]}:${m[2]}`;
    }
    const d = new Date(dateLike);
    if (!isNaN(d)) {
      const hh = String(d.getHours()).padStart(2, '0');
      const mm = String(d.getMinutes()).padStart(2, '0');
      return `${hh}:${mm}`;
    }
    return '';
  };

  const sameDay = (a, b) => (
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
  );

  const dayIndexMondayFirst = (date) => (date.getDay() + 6) % 7;

  const [selectedDate, setSelectedDate] = useState(() => new Date());
  const [currentMonth, setCurrentMonth] = useState(() => new Date());

  // Formateur
  const isFormateur = userService.isFormateur && userService.isFormateur();
  const [trainerAppointments, setTrainerAppointments] = useState([]);
  const [trainerLoading, setTrainerLoading] = useState(false);
  const [creatorMap, setCreatorMap] = useState({}); // id -> { prenom, nom, email }
  const [creatorLabelByRdv, setCreatorLabelByRdv] = useState({}); // rdvId -> string label

  // Filtres simplifiés (JS)
  const [filters, setFilters] = useState({
    statut: [],
    medecin: undefined,
    patientId: undefined,
    dateDebut: undefined,
    dateFin: undefined,
    page: 1,
    limit: 25
  });

  // Chargement des données
  const loadAppointments = useCallback(async () => {
    try {
      setLoading(true);
      const [data, statusAgg] = await Promise.all([
        appointmentService.getAllAppointments(filters),
        appointmentService.getRendezVousStatus().catch(() => null)
      ]);
      const list = Array.isArray(data) ? data : [];
      // Tri du plus récent au plus ancien
      list.sort((a, b) => new Date(b.startAt || b.start_at || b.dateTime || 0) - new Date(a.startAt || a.start_at || a.dateTime || 0));
      setAppointments(list);
      if (statusAgg && (statusAgg.today || statusAgg.total_par_statut || statusAgg.total_par_mention)) {
        const totals = statusAgg.total_par_statut || statusAgg.total_par_mention || {};
        setStats({
          total: Number(statusAgg.today?.total ?? list.length),
          confirmes: Number(statusAgg.today?.confirmes ?? totals.CONFIRME ?? 0),
          planifies: Number(statusAgg.today?.planifies ?? totals.PLANIFIE ?? 0),
          annules: 0,
          termines: 0,
          absents: Number(statusAgg.today?.absents ?? totals.ABSENT ?? 0),
        });
      } else {
        setStats({
          total: list.length,
          confirmes: list.filter(a => a.statut === 'CONFIRME').length,
          planifies: list.filter(a => a.statut === 'PLANIFIE').length,
          annules: list.filter(a => a.statut === 'ANNULE').length,
          termines: list.filter(a => a.statut === 'TERMINE').length,
          absents: list.filter(a => a.statut === 'ABSENT').length,
        });
      }
    } catch (err) {
      setError(err.message || 'Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  // Charger référentiels
  useEffect(() => {
    (async () => {
      try {
        const [p, m] = await Promise.all([
          patientService.getAllPatients({ limit: 200 }).catch(() => []),
          medecinService.getAllMedecins().catch(() => [])
        ]);
        setPatients(Array.isArray(p) ? p : []);
        setMedecins(Array.isArray(m) ? m : []);
      } catch {}
    })();
  }, []);

  // Charger l'agenda d'un médecin sélectionné (plage = jour sélectionné -> +7 jours)
  useEffect(() => {
    (async () => {
      if (!selectedMedecinId) return;
      try {
        setLoading(true);
        const from = selectedDate.toISOString().slice(0,10);
        const toDate = new Date(selectedDate);
        toDate.setDate(toDate.getDate() + 7);
        const to = toDate.toISOString().slice(0,10);
        const list = await appointmentService.getAgenda({ medecin_id: selectedMedecinId, from, to });
        setAppointments(Array.isArray(list) ? list : []);
      } catch (err) {
        setError(err?.message || 'Erreur chargement agenda');
      } finally {
        setLoading(false);
      }
    })();
  }, [selectedMedecinId, selectedDate]);

  // Charger RDV créés par des stagiaires (vue formateur)
  useEffect(() => {
    if (!isFormateur) return;
    (async () => {
      try {
        setTrainerLoading(true);
        const page1 = await appointmentService.getFormateurAppointments(1, 50);
        const list = Array.isArray(page1) ? page1 : [];
        list.sort((a, b) => new Date(b.startAt || b.start_at || b.dateTime || 0) - new Date(a.startAt || a.start_at || a.dateTime || 0));
        setTrainerAppointments(list);
      } finally {
        setTrainerLoading(false);
      }
    })();
  }, [isFormateur]);

  // Résolution externe désactivée: l'endpoint formateur renvoie désormais created_by complet
  useEffect(() => { /* no-op */ }, [isFormateur, trainerAppointments]);

  // Enrichissement via détails désactivé (le back fournit created_by directement)
  useEffect(() => { /* no-op */ }, [isFormateur, trainerAppointments, creatorLabelByRdv]);

  // Recharger quand les filtres changent
  useEffect(() => {
    loadAppointments();
  }, [loadAppointments]);
  // Vue exclusive pour FORMATEUR: afficher uniquement la liste des RDV créés par des stagiaires
  if (isFormateur) {
    return (
      <div className="min-h-screen p-6">
        <div className="text-center py-6">
          <div className="bg-pink-200 rounded-lg shadow p-6 max-w-xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-2">
              <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center shadow-sm">
                <span className="material-symbols-rounded text-pink-600 text-2xl">calendar_month</span>
              </div>
              <h1 className="text-2xl font-bold text-pink-800">Rendez-Vous</h1>
            </div>
            <p className="text-pink-700 text-sm">RDV créés par les stagiaires</p>
          </div>
        </div>

        <div className="bg-pink-200 rounded-lg shadow">
          <div className="px-6 py-4 border-b-2 border-pink-300 bg-pink-50 flex items-center justify-between gap-3 flex-wrap">
            <h3 className="text-lg font-semibold text-pink-800 flex items-center gap-2 m-0">
              <span className="material-symbols-rounded text-pink-600">assignment_ind</span>
              Liste des rendez-vous
              <span className="ml-2 inline-flex items-center px-2 py-0.5 text-xs rounded-full bg-pink-100 text-pink-800 border border-pink-300">{trainerAppointments.length}</span>
            </h3>
          </div>

          <div className="p-6">
            {trainerLoading ? (
              <div className="text-center py-6 text-pink-700">Chargement…</div>
            ) : trainerAppointments.length === 0 ? (
              <div className="text-center py-6 text-gray-500">Aucun rendez-vous créé par des stagiaires</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead className="bg-pink-100">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Heure</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Patient</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Médecin</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Motif</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Statut</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Créé par</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-pink-200">
                    {trainerAppointments.map((rdv, index) => {
                      
                      const d = new Date(rdv.startAt || rdv.start_at || rdv.appointmentTime || rdv.startTime || rdv.dateTime);
                      const dateStr = !isNaN(d) ? d.toLocaleDateString('fr-FR') : '—';
                      const timeStr = !isNaN(d) ? d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '—';
                      const patient = rdv.patient || {};
                      const medecin = rdv.medecin || rdv.doctor || {};
                      const statut = rdv.statut || rdv.status || 'PLANIFIE';
                      // Lecture prioritaire de l'endpoint formateur (objet complet)
                      const creatorObject = (rdv && typeof rdv.created_by === 'object') ? rdv.created_by : null;
                      const creatorRaw = creatorObject || rdv.created_by || rdv.createdBy || rdv.created_by_id || rdv.createdById || rdv.user_id || rdv.user || rdv.creePar || null;
                      let creatorName = '—';
                      if (creatorObject) {
                        const fn = creatorObject.prenom || creatorObject.firstName || '';
                        const ln = creatorObject.nom || creatorObject.lastName || '';
                        const email = creatorObject.email || '';
                        const name = `${fn} ${ln}`.trim();
                        creatorName = name || email || '—';
                      } else if (creatorRaw) {
                        if (typeof creatorRaw === 'string') {
                          const fallbackName = rdv.created_by_name || rdv.createdByName || '';
                          const fallbackEmail = rdv.created_by_email || rdv.createdByEmail || '';
                          const id = creatorRaw.includes('/') ? creatorRaw.split('/').pop() : creatorRaw;
                          const inMap = id ? creatorMap[id] : undefined;
                          const mapName = inMap ? `${inMap.prenom || ''} ${inMap.nom || ''}`.trim() || inMap.email : '';
                          creatorName = mapName || fallbackName || fallbackEmail || id || '—';
                          
                        } else if (typeof creatorRaw === 'number') {
                          const id = String(creatorRaw);
                          const inMap = creatorMap[id];
                          const mapName = inMap ? `${inMap.prenom || ''} ${inMap.nom || ''}`.trim() || inMap.email : '';
                          creatorName = mapName || id || '—';
                          
                        } else {
                          const fn = creatorRaw.prenom || creatorRaw.firstName || '';
                          const ln = creatorRaw.nom || creatorRaw.lastName || '';
                          const email = creatorRaw.email || '';
                          const name = `${fn} ${ln}`.trim();
                          creatorName = name || email || '—';
                          
                        }
                      }
                      if (creatorName === '—') {
                        const extra = creatorLabelByRdv[rdv.id];
                        if (extra) creatorName = extra;
                      }
                      return (
                        <tr key={rdv.id || index} className="hover:bg-pink-50">
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{dateStr}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{timeStr}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{patient.prenom || ''} {patient.nom || ''}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{medecin.prenom || ''} {medecin.nom || ''}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{rdv.motif || '—'}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{statut}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{creatorName}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // (Chargement RDV patients retiré)

  // Génère les 6 semaines affichées (42 cases), en commençant lundi
  const calendarDays = React.useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const start = new Date(firstDay);
    const offset = dayIndexMondayFirst(firstDay);
    start.setDate(1 - offset);
    const days = [];
    const cursor = new Date(start);
    for (let i = 0; i < 42; i++) {
      days.push(new Date(cursor));
      cursor.setDate(cursor.getDate() + 1);
    }
    return days;
  }, [currentMonth]);

  // Créneaux demi-heure
  const timeSlots = React.useMemo(() => {
    const slots = [];
    for (let hour = HOURS_START; hour < HOURS_END; hour++) {
      for (let minute = 0; minute < 60; minute += SLOT_MINUTES) {
        const start = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`;
        const endMinutesTotal = hour * 60 + minute + SLOT_MINUTES;
        const endH = Math.floor(endMinutesTotal / 60);
        const endM = endMinutesTotal % 60;
        const end = `${endH.toString().padStart(2, "0")}:${endM.toString().padStart(2, "0")}`;
        slots.push({ start, end });
      }
    }
    return slots;
  }, []);

  // Couleurs statut alignées avec la page complète
  const getPlanningClasses = (statut) => {
    switch (statut) {
      case 'EN_ATTENTE': return { box: 'bg-yellow-50 border-l-4 border-l-yellow-500', badge: 'bg-yellow-100 text-yellow-800', border: 'border-l-yellow-500' };
      case 'PLANIFIE': return { box: 'bg-blue-50 border-l-4 border-l-blue-500', badge: 'bg-blue-100 text-blue-800', border: 'border-l-blue-500' };
      case 'CONFIRME': return { box: 'bg-green-50 border-l-4 border-l-green-500', badge: 'bg-green-100 text-green-800', border: 'border-l-green-500' };
      case 'ANNULE': return { box: 'bg-red-50 border-l-4 border-l-red-500', badge: 'bg-red-100 text-red-800', border: 'border-l-red-500' };
      case 'ABSENT': return { box: 'bg-purple-50 border-l-4 border-l-purple-500', badge: 'bg-purple-100 text-purple-800', border: 'border-l-purple-500' };
      case 'TERMINE': return { box: 'bg-gray-50 border-l-4 border-l-gray-500', badge: 'bg-gray-100 text-gray-800', border: 'border-l-gray-500' };
      default: return { box: 'bg-blue-50 border-l-4 border-l-blue-500', badge: 'bg-blue-100 text-blue-800', border: 'border-l-blue-500' };
    }
  };

  const getListBg = (statut) => {
    switch (statut) {
      case 'EN_ATTENTE': return 'bg-yellow-50';
      case 'PLANIFIE': return 'bg-blue-50';
      case 'CONFIRME': return 'bg-green-50';
      case 'ANNULE': return 'bg-red-50';
      case 'ABSENT': return 'bg-purple-50';
      case 'TERMINE': return 'bg-gray-50';
      default: return 'bg-blue-50';
    }
  };

  // RDV filtrés sur la journée sélectionnée
  const dayAppointments = React.useMemo(() => {
    const day = selectedDate;
    return (appointments || [])
      .filter(r => r?.statut !== 'ANNULE')
      .filter(r => {
        const d = new Date(r.startAt || r.start_at || r.appointmentTime || r.startTime || r.dateTime);
        return !isNaN(d) && sameDay(d, day);
      });
  }, [appointments, selectedDate]);

  // Indexation des RDV par créneau (HH:mm)
  const appointmentsBySlot = React.useMemo(() => {
    const map = new Map();
    timeSlots.forEach(slot => map.set(slot.start, []));
    for (const appt of dayAppointments) {
      const dateFields = [appt.startAt, appt.start_at, appt.appointmentTime, appt.startTime, appt.dateTime];
      let key = '';
      for (const field of dateFields) {
        if (!field) continue;
        const hhmm = extractHHmm(field);
        if (hhmm) { key = hhmm; break; }
      }
      if (key && map.has(key)) map.get(key).push(appt);
    }
    return map;
  }, [dayAppointments, timeSlots]);

  // Calcul des créneaux occupés par la durée (ex: 60min couvre 2 slots de 30min)
  const getApptDurationMinutes = (appt) => {
    // Priorités: champ direct, synonymes, calcul end-start, fallback 30
    const direct = appt?.duree ?? appt?.duration ?? appt?.dureeMinutes ?? appt?.lengthMinutes;
    if (typeof direct === 'number' && !isNaN(direct)) return direct;
    if (typeof direct === 'string' && direct.trim() && !isNaN(parseInt(direct, 10))) return parseInt(direct, 10);
    const start = appt?.startAt || appt?.start_at || appt?.appointmentTime || appt?.startTime || appt?.dateTime;
    const end = appt?.endAt || appt?.end_at || appt?.endTime;
    if (start && end) {
      const ds = new Date(start);
      const de = new Date(end);
      if (!isNaN(ds) && !isNaN(de)) {
        const mins = Math.max(0, Math.round((de.getTime() - ds.getTime()) / 60000));
        if (mins > 0) return mins;
      }
    }
    return 30;
  };

  const occupiedContinuationSlots = React.useMemo(() => {
    const occupied = new Set();
    const slotIndexByStart = new Map(timeSlots.map((s, idx) => [s.start, idx]));
    for (const appt of dayAppointments) {
      const dateFields = [appt.startAt, appt.start_at, appt.appointmentTime, appt.startTime, appt.dateTime];
      let startKey = '';
      for (const field of dateFields) {
        if (!field) continue;
        const hhmm = extractHHmm(field);
        if (hhmm) { startKey = hhmm; break; }
      }
      if (!startKey) continue;
      const startIdx = slotIndexByStart.get(startKey);
      if (startIdx === undefined) continue;
      const dureeMin = getApptDurationMinutes(appt);
      const slotsToCover = Math.ceil(dureeMin / SLOT_MINUTES);
      for (let i = 1; i < slotsToCover; i++) {
        const idx = startIdx + i;
        if (idx >= 0 && idx < timeSlots.length) {
          occupied.add(timeSlots[idx].start);
        }
      }
    }
    return occupied;
  }, [dayAppointments, timeSlots]);

  const formatEndTimeFrom = (startHHmm, dureeMin) => {
    if (!startHHmm) return '';
    const [h, m] = startHHmm.split(":").map(n => parseInt(n, 10));
    const startTotal = h * 60 + m;
    const endTotal = startTotal + (parseInt(dureeMin || 30, 10));
    const endH = Math.floor(endTotal / 60);
    const endM = endTotal % 60;
    return `${endH.toString().padStart(2, '0')}:${endM.toString().padStart(2, '0')}`;
  };

  const formatRangeForAppointment = (appt) => {
    const startRaw = appt?.startAt || appt?.start_at || appt?.appointmentTime || appt?.startTime || appt?.dateTime;
    const startHHmm = extractHHmm(startRaw);
    if (!startHHmm) return '';
    const endRaw = appt?.endAt || appt?.end_at || appt?.endTime;
    let endHHmm = extractHHmm(endRaw);
    if (!endHHmm) {
      const dmin = getApptDurationMinutes(appt);
      endHHmm = formatEndTimeFrom(startHHmm, dmin);
    }
    return `${startHHmm} à ${endHHmm}`;
  };

  const goToPreviousMonth = () => setCurrentMonth(m => new Date(m.getFullYear(), m.getMonth() - 1, 1));
  const goToNextMonth = () => setCurrentMonth(m => new Date(m.getFullYear(), m.getMonth() + 1, 1));

  // Actions RDV
  const handleAction = async (id, action) => {
    try {
      setLoading(true);
      const appt = (appointments || []).find(a => a.id === id);
      // Construit un payload minimal conforme à la validation backend
      let payload = undefined;
      if (appt) {
        const start = appt?.startAt || appt?.start_at;
        let d = null;
        if (typeof start === 'string' && start) {
          // Tente de parser "YYYY-MM-DD HH:mm:ss" ou ISO en LOCAL
          const s = start.replace('T', ' ');
          const m = s.match(/^(\d{4})-(\d{2})-(\d{2})\s(\d{2}):(\d{2})(?::(\d{2}))?/);
          if (m) {
            const [, y, mo, da, hh, mm, ss] = m;
            d = new Date(parseInt(y,10), parseInt(mo,10)-1, parseInt(da,10), parseInt(hh,10), parseInt(mm,10), ss?parseInt(ss,10):0, 0);
          } else {
            const tmp = new Date(start);
            if (!isNaN(tmp)) d = tmp;
          }
        }
        const startStr = d && !isNaN(d) ? formatDateTimeForApi(d) : undefined;
        const dureeMinutes = getApptDurationMinutes(appt);
        const endDate = d && dureeMinutes ? new Date(d.getTime() + dureeMinutes * 60000) : null;
        const endStr = endDate ? formatDateTimeForApi(endDate) : undefined;
        payload = {
          ...(startStr ? { start_at: startStr } : {}),
          ...(endStr ? { end_at: endStr } : {}),
          ...(dureeMinutes ? { dureeMinutes: dureeMinutes } : {}),
        };
      }

      if (action === 'CONFIRME') {
        await appointmentService.updateAppointment(id, { ...(payload || {}), statut: 'CONFIRME' });
      } else if (action === 'ANNULE') {
        try {
          await appointmentService.deleteAppointment(id);
        } catch (_) {
          await appointmentService.updateAppointment(id, { statut: 'ANNULE' });
        }
      } else if (action === 'ABSENT') {
        // garde l'endpoint dédié si dispo
        await appointmentService.markAsAbsent(id);
    } else {
        await appointmentService.updateAppointment(id, { ...(payload || {}), statut: action });
      }
      await loadAppointments();
    } catch (e) {
      setError("Erreur lors de l'action: " + (e?.message || ''));
    } finally {
      setLoading(false);
    }
  };

  // Edition de statut (corriger une erreur)
  const [editStatusId, setEditStatusId] = useState(null);
  const [editStatusValue, setEditStatusValue] = useState('');

  // Création RDV (modal simple)
  const [showCreate, setShowCreate] = useState(false);
  const [newAppt, setNewAppt] = useState({ patient: '', medecin: '', motif: '', date: '', heure: '', duree: '30', notes: '' });
  const [createError, setCreateError] = useState('');
  // Édition RDV
  const [showEdit, setShowEdit] = useState(false);
  const [editApptId, setEditApptId] = useState(null);
  const [editAppt, setEditAppt] = useState({ patient: '', medecin: '', motif: '', date: '', heure: '', duree: '30', notes: '' });
  const [editError, setEditError] = useState('');

  // util: format YYYY-MM-DD HH:mm:ss (local time)
  const formatDateTimeForApi = (d) => {
    if (!d || isNaN(d)) return '';
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const HH = String(d.getHours()).padStart(2, '0');
    const MM = String(d.getMinutes()).padStart(2, '0');
    const SS = String(d.getSeconds()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd} ${HH}:${MM}:${SS}`;
  };

  const isWithinWorkingHours = (start, end) => {
    if (!start || !end || isNaN(start) || isNaN(end)) return false;
    const day = start.getDay(); // 0=dim,6=sam
    if (day === 0 || day === 6) return false;
    const startMinutes = start.getHours() * 60 + start.getMinutes();
    const endMinutes = end.getHours() * 60 + end.getMinutes();
    const minMinutes = 8 * 60;
    const maxMinutes = 18 * 60;
    return startMinutes >= minMinutes && endMinutes <= maxMinutes && end > start;
  };

  const createAppointment = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      setCreateError('');
      // Construire la date en LOCAL pour éviter tout décalage de fuseau
      const [sy, sm, sd] = (newAppt.date || '').split('-').map(n => parseInt(n, 10));
      const [sh, smin] = (newAppt.heure || '00:00').split(':').map(n => parseInt(n, 10));
      const startDate = (Number.isFinite(sy) && Number.isFinite(sm) && Number.isFinite(sd))
        ? new Date(sy, (sm - 1), sd, sh || 0, smin || 0, 0, 0)
        : new Date();
      const endDate = new Date(startDate.getTime() + (parseInt(newAppt.duree || '30') * 60 * 1000));
      const startStr = formatDateTimeForApi(startDate);
      const endStr = formatDateTimeForApi(endDate);

      // Vérifications horaires (avant appel API)
      if (!isWithinWorkingHours(startDate, endDate)) {
        setCreateError('Créneau invalide: jours ouvrés 08:00–18:00, fin > début.');
        setLoading(false);
        return;
      }

      // Vérification de conflit avant création
      try {
        const { conflict, message } = await appointmentService.verifyConflict({
          patient_id: newAppt.patient || '',
          start_at: startStr,
          end_at: endStr,
        });
        if (conflict) {
          setCreateError('Le praticien a déjà un rendez-vous à cette heure');
          setLoading(false);
          return;
        }
      } catch (_) { /* noop: on tente quand même si endpoint indisponible */ }
      const payload = {
        patient: newAppt.patient ? `/api/patients/${newAppt.patient}` : '',
        start_at: startStr,
        motif: newAppt.motif,
        statut: 'PLANIFIE',
        dureeMinutes: parseInt(newAppt.duree || '30'),
        notes: newAppt.notes,
        medecin: newAppt.medecin
      };
      console.debug('[RDV] CREATE payload=', payload);
      await appointmentService.createAppointment(payload);
      console.debug('[RDV] CREATE ok');
      setShowCreate(false);
      setNewAppt({ patient: '', medecin: '', motif: '', date: '', heure: '', duree: '30', notes: '' });
      await loadAppointments();
    } catch (e) {
      const msg = (e?.response?.data?.message || e?.message || '').toString().toLowerCase();
      if (e?.response?.status === 409 || msg.includes('déjà un rendez-vous')) {
        setCreateError('Le praticien a déjà un rendez-vous à cette heure');
      } else {
        setCreateError("Impossible de créer le rendez-vous. Vérifiez les champs.");
      }
    } finally {
      setLoading(false);
    }
  };

  // Ouvrir la création pré-remplie à partir d'un RDV annulé
  const openReschedule = (appt) => {
    if (!appt) return;
    const start = appt?.startAt || appt?.start_at || appt?.appointmentTime || appt?.startTime || appt?.dateTime;
    const d = start ? new Date(start) : null;
    const date = d && !isNaN(d) ? d.toISOString().split('T')[0] : '';
    const heure = d && !isNaN(d) ? `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}` : '';
    const duree = String(getApptDurationMinutes(appt));

    setNewAppt({
      patient: appt?.patient?.id || '',
      medecin: appt?.medecin?.id || appt?.doctor?.id || '',
      motif: appt?.motif || '',
      date,
      heure,
      duree,
      notes: appt?.notes || ''
    });
    setShowCreate(true);
  };

  const openEdit = (appt) => {
    if (!appt) return;
    const start = appt?.startAt || appt?.start_at || appt?.appointmentTime || appt?.startTime || appt?.dateTime;
    const d = start ? new Date(start) : null;
    const date = d && !isNaN(d) ? d.toISOString().split('T')[0] : '';
    const heure = d && !isNaN(d) ? `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}` : '';
    setEditAppt({
      patient: appt?.patient?.id || '',
      medecin: appt?.medecin?.id || appt?.doctor?.id || '',
      motif: appt?.motif || '',
      date,
      heure,
      duree: String(getApptDurationMinutes(appt)),
      notes: appt?.notes || ''
    });
    setEditApptId(appt.id);
    setEditError('');
    setShowEdit(true);
  };

  const submitEdit = async (e) => {
    e.preventDefault();
    if (!editApptId) return;
    try {
      setLoading(true);
      setEditError('');
      const [ey, em, ed] = (editAppt.date || '').split('-').map(n => parseInt(n, 10));
      const [eh, emin] = (editAppt.heure || '00:00').split(':').map(n => parseInt(n, 10));
      const startDate = (Number.isFinite(ey) && Number.isFinite(em) && Number.isFinite(ed))
        ? new Date(ey, (em - 1), ed, eh || 0, emin || 0, 0, 0)
        : new Date();
      const endDate = new Date(startDate.getTime() + (parseInt(editAppt.duree || '30') * 60 * 1000));
      const startStr = formatDateTimeForApi(startDate);
      const endStr = formatDateTimeForApi(endDate);

      // Vérifications horaires (avant appel API)
      if (!isWithinWorkingHours(startDate, endDate)) {
        setEditError('Créneau invalide: jours ouvrés 08:00–18:00, fin > début.');
        setLoading(false);
        return;
      }

      // Vérification de conflit avant édition
      try {
        const { conflict } = await appointmentService.verifyConflict({
          patient_id: editAppt.patient || '',
          start_at: startStr,
          end_at: endStr,
          exclude_id: editApptId,
        });
        if (conflict) {
          setEditError('Le praticien a déjà un rendez-vous à cette heure');
      setLoading(false);
          return;
        }
      } catch (_) { /* noop */ }
      const payload = {
        patient: editAppt.patient ? `/api/patients/${editAppt.patient}` : undefined,
        start_at: startStr,
        end_at: endStr,
        motif: editAppt.motif,
        // on laisse le back prioriser end_at; dureeMinutes optionnel
        dureeMinutes: parseInt(editAppt.duree || '30'),
        notes: editAppt.notes,
        medecin: editAppt.medecin || undefined
      };
      console.debug('[RDV] EDIT payload=', payload);
      await appointmentService.updateAppointment(editApptId, payload);
      console.debug('[RDV] EDIT ok');
      setShowEdit(false);
      await loadAppointments();
    } catch (e) {
      const backendMsgRaw = e?.response?.data?.message || e?.response?.data?.detail;
      const msg = (backendMsgRaw || e?.message || '').toString().toLowerCase();
      if (e?.response?.status === 409 || msg.includes('déjà un rendez-vous')) {
        setEditError('Le praticien a déjà un rendez-vous à cette heure');
      } else {
        setEditError(backendMsgRaw || 'Impossible de modifier le rendez-vous.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Boutons rapides pour les filtres
  const quickFilters = [
    { label: 'Aujourd\'hui', action: () => {
      const today = new Date().toISOString().split('T')[0];
      setFilters(f => ({ ...f, dateDebut: today, dateFin: today }));
    }},
    { label: 'Cette semaine', action: () => {
      const today = new Date();
      const weekStart = new Date(today);
      weekStart.setDate(today.getDate() - today.getDay());
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      
      setFilters(f => ({ 
        ...f, 
        dateDebut: weekStart.toISOString().split('T')[0],
        dateFin: weekEnd.toISOString().split('T')[0]
      }));
    }},
    { label: 'Planifiés', action: () => {
      setFilters(f => ({ ...f, statut: ['PLANIFIE'] }));
    }},
    { label: 'Confirmés', action: () => {
      setFilters(f => ({ ...f, statut: ['CONFIRME'] }));
    }},
    { label: 'Absents', action: () => {
      setFilters(f => ({ ...f, statut: ['ABSENT'] }));
    }},
    { label: 'Tous', action: () => {
      setFilters(f => ({ 
        ...f, 
        statut: [], 
        medecin: undefined, 
        patientId: undefined,
        dateDebut: undefined,
        dateFin: undefined
      }));
    }}
  ];

  return (
    <div className="min-h-screen p-6">
      
      {/* Titre centré avec icône et description */}
      <div className="text-center py-6 mb-6">
        <div className="bg-pink-200 rounded-lg shadow p-6 max-w-xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center shadow-sm">
              <span className="material-symbols-rounded text-pink-600 text-2xl">calendar_month</span>
            </div>
            <h1 className="text-2xl font-bold text-pink-800">Rendez-Vous</h1>
          </div>
          <p className="text-pink-700 text-sm">
            Gérez et planifiez vos rendez-vous médicaux
          </p>
        </div>
      </div>


        {/* Stats (même visuel que la page complète) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div className="bg-pink-50 rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-pink-700">Total aujourd'hui</p>
                <p className="text-3xl font-bold text-pink-800">{stats.total}</p>
            </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="material-symbols-rounded text-blue-600">event</span>
              </div>
          </div>
        </div>

        <div className="bg-pink-50 rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-pink-700">Planifiés</p>
              <p className="text-3xl font-bold text-pink-800">{stats.planifies}</p>
            </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="material-symbols-rounded text-blue-600">event_upcoming</span>
              </div>
          </div>
        </div>
        <div className="bg-pink-50 rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-pink-700">Confirmés</p>
              <p className="text-3xl font-bold text-pink-800">{stats.confirmes}</p>
            </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <span className="material-symbols-rounded text-green-600">check_circle</span>
              </div>
          </div>
        </div>
        
        <div className="bg-pink-50 rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-pink-700">Absents</p>
              <p className="text-3xl font-bold text-pink-800">{stats.absents}</p>
            </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="material-symbols-rounded text-purple-600">person_off</span>
              </div>
          </div>
        </div>
      </div>

      {/* Bouton de sélection médecin centré entre stats et calendrier */}
      <div className="flex justify-center mb-6">
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowDoctorPicker(v => !v)}
            className="inline-flex flex-col items-center gap-1 px-4 py-2 rounded-full bg-pink-600 text-white text-base font-bold hover:bg-pink-700 shadow text-center"
          >
            <span className="inline-flex items-center gap-2">
              <span className="material-symbols-rounded text-sm">stethoscope</span>
              {selectedMedecinId ? 'Changer de médecin' : 'Choisir le médecin'}
            </span>
            {selectedMedecinId && (
              <span className="block text-sm md:text-base font-bold opacity-95 leading-tight">
                {(() => {
                  const m = medecins.find(x => x.id === selectedMedecinId);
                  if (!m) return '';
                  const lastUpper = (m.nom || '').toUpperCase();
                  const first = m.prenom || '';
                  const spec = m?.specialite?.label || m?.specialite?.nom || m?.specialite || m?.specialty?.name || m?.specialty || '';
                  return `Dr ${lastUpper} ${first}${spec ? ' — ' + spec : ''}`.trim();
                })()}
              </span>
            )}
          </button>
          {showDoctorPicker && (
            <select
              id="doctorPickerInline"
              value={selectedMedecinId}
              onChange={(e) => { setSelectedMedecinId(e.target.value); setShowDoctorPicker(false); }}
              onBlur={() => setShowDoctorPicker(false)}
              className="absolute left-1/2 -translate-x-1/2 top-full mt-2 z-10 border border-pink-300 rounded px-2 py-1 bg-white text-sm shadow"
            >
              <option value="">— Tous —</option>
              {medecins.map(m => { const spec = m?.specialite?.label || m?.specialite?.nom || m?.specialite || m?.specialty?.name || m?.specialty || ''; const label = `${m.prenom || ''} ${m.nom || ''}${spec ? ' — ' + spec : ''}`.trim(); return (<option key={m.id} value={m.id}>{label}</option>); })}
            </select>
          )}
        </div>
      </div>

      {/* Calendrier réduit (même esprit que la page complète) */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-xl font-bold text-pink-800 flex items-center gap-2 m-0">
          <span className="material-symbols-rounded text-pink-600">calendar_month</span>
          Calendrier
        </h3>
          <div />
        </div>
        <div className="flex items-center justify-between mb-4">
          <button onClick={goToPreviousMonth} className="p-2 hover:bg-pink-100 rounded-lg transition-colors text-pink-700">
            <span className="material-symbols-rounded">chevron_left</span>
          </button>
          <h4 className="text-lg font-semibold text-pink-700">
            {currentMonth.toLocaleDateString("fr-FR", { month: "long", year: "numeric" })}
          </h4>
          <button onClick={goToNextMonth} className="p-2 hover:bg-pink-100 rounded-lg transition-colors text-pink-700">
            <span className="material-symbols-rounded">chevron_right</span>
          </button>
        </div>
        <div className="grid grid-cols-7 gap-1 mb-2">
          {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((day) => (
            <div key={day} className="p-2 text-center text-sm font-medium text-pink-600">{day}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((date) => {
            const isCurrentMonth = date.getMonth() === currentMonth.getMonth();
            const key = toISODate(date);
            const today = sameDay(date, new Date());
            const selected = sameDay(date, selectedDate);
            return (
              <button
                key={key}
                onClick={() => setSelectedDate(date)}
                className={`p-2 text-sm rounded-lg transition-colors ${!isCurrentMonth ? "text-gray-300" : "text-pink-700 hover:bg-pink-100"} ${today ? "bg-pink-300 text-pink-900 font-semibold" : ""} ${selected ? "bg-pink-500 text-white font-semibold" : ""}`}
                aria-label={date.toDateString()}
              >
                {date.getDate()}
              </button>
            );
          })}
        </div>
      </div>

      {/* Planning de la journée (agenda) */}
      <div className="bg-pink-200 rounded-lg shadow">
        <div className="p-6 border-b-2 border-pink-300 bg-pink-50">
          <h3 className="text-lg font-semibold text-pink-800 flex items-center gap-2">
            <svg className="w-5 h-5 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {selectedDate.toLocaleDateString("fr-FR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })} — Planning {loading ? "(chargement…)" : ""}
          </h3>
        </div>
        <div className="p-6 bg-pink-200">
          <div className="grid grid-cols-2 gap-4 mb-4 pb-2 border-b-2 border-pink-200">
            <div className="font-medium text-pink-700 text-sm text-center bg-pink-100 py-2 rounded-lg flex items-center justify-center gap-2">
              <span className="material-symbols-rounded">wb_sunny</span>
              Matin (8h-13h)
            </div>
            <div className="font-medium text-pink-700 text-sm text-center bg-pink-100 py-2 rounded-lg flex items-center justify-center gap-2">
              <span className="material-symbols-rounded">dark_mode</span>
              Après-midi (13h-18h)
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Matin */}
            <div className="space-y-2">
              {timeSlots.filter(s => parseInt(s.start.split(":")[0], 10) >= 8 && parseInt(s.start.split(":")[0], 10) < 13).map(slot => {
                const slotAppointments = appointmentsBySlot.get(slot.start) || [];
                const hasStarter = slotAppointments.length > 0;
                const isContinuation = !hasStarter && occupiedContinuationSlots.has(slot.start);
                const first = slotAppointments[0];
                if (isContinuation) return null; // fusion: ne pas afficher les suites
                const dureeMin = getApptDurationMinutes(first);
                const slotsToCover = hasStarter ? Math.ceil(dureeMin / SLOT_MINUTES) : 1;
                return (
                  <div key={slot.start} style={{ minHeight: HAUTEUR_MIN_CARTE_CRENEAU * slotsToCover }} className={`border border-pink-200 rounded-lg p-3 bg-white transition-all shadow-sm ${hasStarter ? 'hover:bg-pink-50' : 'cursor-pointer hover:bg-pink-100 hover:shadow-md hover:border-pink-300 hover:scale-[1.02]'}`}>
                    <div className="text-sm font-medium text-pink-700 mb-2 font-semibold">{slot.start} - {hasStarter ? formatEndTimeFrom(slot.start, dureeMin) : slot.end}</div>
                    <div>
                      {hasStarter ? (() => {
                        const cls = getPlanningClasses(first?.statut);
                        return (
                          <div className={`${cls.box} p-3 rounded-lg`}>
                            <div className="text-xs">
                              <div className="font-semibold">{first?.patient?.prenom} {first?.patient?.nom}</div>
                              <div className="text-gray-600 mt-1">{first?.motif}</div>
                              <div className="mt-2 flex items-center gap-2"><span className={`px-2 py-1 rounded text-xs font-medium ${cls.badge}`}>{first?.statut}</span>
                                <button onClick={() => openEdit(first)} className="px-2 py-0.5 rounded bg-pink-600 text-white hover:bg-pink-700 text-xs">Modifier</button>
                              </div>
                              
                            </div>
                          </div>
                        );
                      })() : isContinuation ? (
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-pink-600">Occupé (suite)</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end gap-2">
                          <span className="text-xs text-pink-600">Libre</span>
                          <button onClick={() => {
                            const y = selectedDate.getFullYear();
                            const m = String(selectedDate.getMonth() + 1).padStart(2, '0');
                            const d = String(selectedDate.getDate()).padStart(2, '0');
                            setNewAppt(a => ({ ...a, date: `${y}-${m}-${d}`, heure: slot.start }));
                            setShowCreate(true);
                          }} className="text-pink-600 hover:text-pink-800 hover:bg-pink-100 rounded-full p-1 transition-all" title="Ajouter un RDV">
                            <span className="material-symbols-rounded">add</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            {/* Après-midi */}
            <div className="space-y-2">
              {timeSlots.filter(s => parseInt(s.start.split(":")[0], 10) >= 13 && parseInt(s.start.split(":")[0], 10) < 18).map(slot => {
                  const slotAppointments = appointmentsBySlot.get(slot.start) || [];
                const hasStarter = slotAppointments.length > 0;
                const isContinuation = !hasStarter && occupiedContinuationSlots.has(slot.start);
                  const first = slotAppointments[0];
                if (isContinuation) return null; // fusion: ne pas afficher les suites
                const dureeMin = getApptDurationMinutes(first);
                const slotsToCover = hasStarter ? Math.ceil(dureeMin / SLOT_MINUTES) : 1;
                  return (
                  <div key={slot.start} style={{ minHeight: HAUTEUR_MIN_CARTE_CRENEAU * slotsToCover }} className={`border border-pink-200 rounded-lg p-3 bg-white transition-all shadow-sm ${hasStarter ? 'hover:bg-pink-50' : 'cursor-pointer hover:bg-pink-100 hover:shadow-md hover:border-pink-300 hover:scale-[1.02]'}`}>
                    <div className="text-sm font-medium text-pink-700 mb-2 font-semibold">{slot.start} - {hasStarter ? formatEndTimeFrom(slot.start, dureeMin) : slot.end}</div>
                      <div>
                      {hasStarter ? (() => {
                        const cls = getPlanningClasses(first?.statut);
                          return (
                          <div className={`${cls.box} p-3 rounded-lg`}>
                              <div className="text-xs">
                                <div className="font-semibold">{first?.patient?.prenom} {first?.patient?.nom}</div>
                                <div className="text-gray-600 mt-1">{first?.motif}</div>
                              <div className="mt-2 flex items-center gap-2"><span className={`px-2 py-1 rounded text-xs font-medium ${cls.badge}`}>{first?.statut}</span>
                                <button onClick={() => openEdit(first)} className="px-2 py-0.5 rounded bg-pink-600 text-white hover:bg-pink-700 text-xs">Modifier</button>
                                  </div>
                              
                              </div>
                            </div>
                          );
                      })() : isContinuation ? (
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-pink-600">Occupé (suite)</span>
                        </div>
                      ) : (
                          <div className="flex items-center justify-end gap-2">
                            <span className="text-xs text-pink-600">Libre</span>
                          <button onClick={() => {
                            const y = selectedDate.getFullYear();
                            const m = String(selectedDate.getMonth() + 1).padStart(2, '0');
                            const d = String(selectedDate.getDate()).padStart(2, '0');
                            setNewAppt(a => ({ ...a, date: `${y}-${m}-${d}`, heure: slot.start }));
                            setShowCreate(true);
                          }} className="text-pink-600 hover:text-pink-800 hover:bg-pink-100 rounded-full p-1 transition-all" title="Ajouter un RDV">
                            <span className="material-symbols-rounded">add</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>

      {/* Liste des rendez-vous avec entête identique à la page complète */}
      <div className="bg-pink-200 rounded-lg shadow mt-6">
        <div className="px-6 py-4 border-b-2 border-pink-300 bg-pink-50 flex items-center justify-between gap-3 flex-wrap">
          <h3 className="text-lg font-semibold text-pink-800 flex items-center gap-2 m-0">
            <span className="material-symbols-rounded text-pink-600">list</span>
            Liste des rendez-vous
            {selectedMedecinId && (() => {
              const m = medecins.find(x => x.id === selectedMedecinId);
              if (!m) return null;
              const lastUpper = (m.nom || '').toUpperCase();
              const first = m.prenom || '';
              const spec = m?.specialite?.label || m?.specialite?.nom || m?.specialite || m?.specialty?.name || m?.specialty || '';
              return (
                <span className="text-sm font-normal text-pink-700">— du Dr <span className="font-extrabold">{lastUpper}</span> <span className="font-semibold">{first}</span>{spec ? <span> — {spec}</span> : null}</span>
              );
            })()}
            <span className="ml-2 inline-flex items-center px-2 py-0.5 text-xs rounded-full bg-pink-100 text-pink-800 border border-pink-300">{appointments.length}</span>
              </h3>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <button onClick={() => { const today = new Date().toISOString().split('T')[0]; setFilters(f => ({ ...f, dateDebut: today, dateFin: today })); }} className={`px-3 py-1 rounded-full text-xs transition-colors ${filters.dateDebut && filters.dateFin && filters.dateDebut === filters.dateFin && filters.dateDebut === new Date().toISOString().split('T')[0] ? 'bg-pink-100 text-pink-800 border border-pink-300' : 'bg-white text-pink-700 hover:bg-pink-50 border border-pink-300'}`}>Aujourd'hui</button>
            <button onClick={() => { const t = new Date(); const ws = new Date(t); ws.setDate(t.getDate() - t.getDay()); const we = new Date(ws); we.setDate(ws.getDate() + 6); setFilters(f => ({ ...f, dateDebut: ws.toISOString().split('T')[0], dateFin: we.toISOString().split('T')[0] })); }} className={`px-3 py-1 rounded-full text-xs transition-colors ${filters.dateDebut && filters.dateFin ? 'bg-pink-100 text-pink-800 border border-pink-300' : 'bg-white text-pink-700 hover:bg-pink-50 border border-pink-300'}`}>Cette semaine</button>
            <button onClick={() => setFilters(f => ({ ...f, statut: ['PLANIFIE'] }))} className={`px-3 py-1 rounded-full text-xs transition-colors ${filters.statut?.includes('PLANIFIE') ? 'bg-pink-100 text-pink-800 border border-pink-300' : 'bg-white text-pink-700 hover:bg-pink-50 border border-pink-300'}`}>Planifiés</button>
            <button onClick={() => setFilters(f => ({ ...f, statut: ['CONFIRME'] }))} className={`px-3 py-1 rounded-full text-xs transition-colors ${filters.statut?.includes('CONFIRME') ? 'bg-pink-100 text-pink-800 border border-pink-300' : 'bg-white text-pink-700 hover:bg-pink-50 border border-pink-300'}`}>Confirmés</button>
            <button onClick={() => setFilters(f => ({ ...f, statut: ['ABSENT'] }))} className={`px-3 py-1 rounded-full text-xs transition-colors ${filters.statut?.includes('ABSENT') ? 'bg-pink-100 text-pink-800 border border-pink-300' : 'bg-white text-pink-700 hover:bg-pink-50 border border-pink-300'}`}>Absents</button>
            <button onClick={() => setFilters(f => ({ ...f, statut: [], medecin: undefined, patientId: undefined, dateDebut: undefined, dateFin: undefined }))} className="px-3 py-1 rounded-full text-xs bg-white text-pink-700 hover:bg-pink-50 border border-pink-300">Tous</button>
            {/* Filtres Patient/Médecin */}
            <select value={filters.patientId || ''} onChange={(e) => setFilters(f => ({ ...f, patientId: e.target.value || undefined }))} className="px-3 py-1 text-xs border border-pink-300 rounded">
              <option value="">Patient</option>
              {patients.map(p => (
                <option key={p.id} value={p.id}>{p.prenom} {p.nom}</option>
              ))}
            </select>

          {loading && (
              <div className="flex items-center text-sm text-gray-500 ml-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-pink-500 mr-2"></div>
              Chargement...
            </div>
          )}
          </div>
        </div>
        <div className="p-6">
        {error && (
            <div className="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded mb-4">{error}</div>
        )}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-500 mx-auto"></div>
            <p className="mt-2 text-gray-600">Chargement des rendez-vous...</p>
            </div>
        ) : appointments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">Aucun rendez-vous trouvé</div>
        ) : (
            <div className="space-y-4">
            {appointments.filter(a => a?.statut !== 'ANNULE').map((appointment) => {
              const patient = appointment.patient || {};
              const d = new Date(appointment.startAt || appointment.start_at || appointment.dateTime);
              const initials = `${patient.prenom?.[0] || ''}${patient.nom?.[0] || ''}`;
                const cls = getPlanningClasses(appointment.statut);
                return (
                  <div key={appointment.id} className={`p-4 rounded-r-lg border-l-4 ${cls.border} ${getListBg(appointment.statut)}`}> 
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4">
                          <div className={`w-12 h-12 ${cls.badge} rounded-full flex items-center justify-center`}>
                          <span className={`font-semibold text-lg`}>{initials}</span>
                          </div>
                          <div>
                            <div className="font-semibold text-gray-800">
                              {patient.prenom} {patient.nom}
                            </div>
                            <div className="text-sm text-gray-600">
                          {appointment.motif} • {appointment.medecin?.prenom} {appointment.medecin?.nom} • {d.toLocaleDateString('fr-FR')} • {formatRangeForAppointment(appointment)}
                            </div>
                        {isFormateur && (
                          <div className="text-xs text-gray-500 mt-1">
                            {(() => {
                              const raw = appointment.createdBy || appointment.created_by || appointment.creePar || appointment.user || null;
                              if (!raw) return 'Créé par: —';
                              if (typeof raw === 'string') {
                                const fallbackName = appointment.created_by_name || appointment.createdByName || '';
                                const fallbackEmail = appointment.created_by_email || appointment.createdByEmail || '';
                                const val = fallbackName || fallbackEmail || (raw.split('/').pop() || '—');
                                return `Créé par: ${val}`;
                              }
                              const fn = raw.prenom || raw.firstName || '';
                              const ln = raw.nom || raw.lastName || '';
                              const email = raw.email || '';
                              const name = `${fn} ${ln}`.trim() || email || '—';
                              return `Créé par: ${name}`;
                            })()}
                          </div>
                        )}
                            <div className="text-xs text-gray-500 mt-1">
                              {patient.telephone && (
                                <span className="inline-flex items-center gap-1 mr-2">
                                  <span className="material-symbols-rounded text-gray-500 text-sm">call</span>
                                  {patient.telephone}
                                </span>
                              )}
                              {patient.email && (
                                <span className="inline-flex items-center gap-1">
                                  <span className="material-symbols-rounded text-gray-500 text-sm">mail</span>
                                  {patient.email}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${cls.badge}`}>{appointment.statut}</span>
                      {appointment.statut === 'PLANIFIE' && (
                        <div className="flex items-center gap-2">
                          <button onClick={() => handleAction(appointment.id, 'CONFIRME')} className="px-3 py-1 rounded bg-green-600 text-white text-xs hover:bg-green-700">Confirmer</button>
                          <button onClick={() => handleAction(appointment.id, 'ABSENT')} className="px-3 py-1 rounded bg-purple-600 text-white text-xs hover:bg-purple-700">Absent</button>
                          <button onClick={() => handleAction(appointment.id, 'ANNULE')} className="px-3 py-1 rounded bg-red-600 text-white text-xs hover:bg-red-700">Annuler</button>
                  </div>
                      )}
                      {appointment.statut !== 'PLANIFIE' && (
                        <div className="flex items-center gap-2">
                              <button
                                onClick={() => {
                              if (editStatusId === appointment.id) {
                                    setEditStatusId(null);
                                    setEditStatusValue('');
                                  } else {
                                setEditStatusId(appointment.id);
                                setEditStatusValue(appointment.statut || 'CONFIRME');
                                  }
                                }}
                            className="px-3 py-1 rounded bg-pink-600 text-white text-xs hover:bg-pink-700"
                              >
                                Modifier
                              </button>
                          
                          {editStatusId === appointment.id && (
                                <div className="flex items-center gap-2">
                                  <select
                                    value={editStatusValue}
                                    onChange={(e) => setEditStatusValue(e.target.value)}
                                    className="px-2 py-1 text-xs border border-pink-300 rounded hover:border-pink-400 bg-white"
                                  >
                                    <option value="PLANIFIE">Planifié</option>
                                    <option value="CONFIRME">Confirmé</option>
                                    <option value="ANNULE">Annulé</option>
                                    <option value="ABSENT">Absent</option>
                                    <option value="TERMINE">Terminé</option>
                                  </select>
                                  <button
                                    onClick={async () => {
                                      if (!editStatusValue) return;
                                      try {
                                        if (editStatusValue === 'ANNULE') {
                                          try {
                                            await appointmentService.deleteAppointment(appointment.id);
                                          } catch (_) {
                                            await appointmentService.updateStatus(appointment.id, 'ANNULE');
                                          }
                                        } else {
                                          await appointmentService.updateStatus(appointment.id, editStatusValue);
                                        }
                                        setEditStatusId(null);
                                        setEditStatusValue('');
                                        await loadAppointments();
                                      } catch (e) {
                                        setError("Erreur lors du changement de statut: " + (e?.message || ''));
                                      }
                                    }}
                                    className="px-3 py-1 rounded bg-pink-600 text-white text-xs hover:bg-pink-700"
                                  >
                                    Enregistrer
                                  </button>
                                </div>
                              )}
          </div>
        )}
      </div>

      {/* Formateur: RDV créés par des stagiaires */}
      {isFormateur && (
        <div className="bg-pink-200 rounded-lg shadow mt-6">
          <div className="px-6 py-4 border-b-2 border-pink-300 bg-pink-50 flex items-center justify-between gap-3 flex-wrap">
            <h3 className="text-lg font-semibold text-pink-800 flex items-center gap-2 m-0">
              <span className="material-symbols-rounded text-pink-600">assignment_ind</span>
              RDV créés par des stagiaires
              <span className="ml-2 inline-flex items-center px-2 py-0.5 text-xs rounded-full bg-pink-100 text-pink-800 border border-pink-300">{trainerAppointments.length}</span>
            </h3>
          </div>
          <div className="p-6">
            {trainerLoading ? (
              <div className="text-center py-6 text-pink-700">Chargement…</div>
            ) : trainerAppointments.length === 0 ? (
              <div className="text-center py-6 text-gray-500">Aucun rendez-vous créé par des stagiaires</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead className="bg-pink-100">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Heure</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Patient</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Médecin</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Motif</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Statut</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-pink-700 uppercase tracking-wider">Créé par</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-pink-200">
                    {trainerAppointments.map((rdv, index) => {
                      const d = new Date(rdv.startAt || rdv.start_at || rdv.appointmentTime || rdv.startTime || rdv.dateTime);
                      const dateStr = !isNaN(d) ? d.toLocaleDateString('fr-FR') : '—';
                      const timeStr = !isNaN(d) ? d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '—';
                      const patient = rdv.patient || {};
                      const medecin = rdv.medecin || rdv.doctor || {};
                      const statut = rdv.statut || rdv.status || 'PLANIFIE';
                      const creatorRaw = rdv.createdBy || rdv.created_by || rdv.creePar || rdv.user || null;
                      let creatorName = '—';
                      if (creatorRaw) {
                        if (typeof creatorRaw === 'string') {
                          const fallbackName = rdv.created_by_name || rdv.createdByName || '';
                          const fallbackEmail = rdv.created_by_email || rdv.createdByEmail || '';
                          creatorName = fallbackName || fallbackEmail || creatorRaw.split('/').pop() || '—';
                        } else {
                          const fn = creatorRaw.prenom || creatorRaw.firstName || '';
                          const ln = creatorRaw.nom || creatorRaw.lastName || '';
                          const email = creatorRaw.email || '';
                          const name = `${fn} ${ln}`.trim();
                          creatorName = name || email || '—';
                        }
                      }
                      return (
                        <tr key={rdv.id || index} className="hover:bg-pink-50">
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{dateStr}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{timeStr}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{patient.prenom || ''} {patient.nom || ''}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{medecin.prenom || ''} {medecin.nom || ''}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{rdv.motif || '—'}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{statut}</td>
                          <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-900">{creatorName}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
                          )}
                        </div>
                      </div>
      )}
                    </div>
                  </div>
                );
              })}
            </div>
        )}
          {/* Pagination simple */}
          <div className="mt-6 flex items-center justify-between">
            <button onClick={() => setFilters(f => ({ ...f, page: Math.max(1, (f.page || 1) - 1) }))} disabled={(filters.page || 1) === 1} className={`px-3 py-1 rounded-lg border transition-colors ${ (filters.page || 1) === 1 ? 'bg-gray-100 text-gray-400 border-gray-200' : 'bg-white hover:bg-pink-50 border-pink-300 text-pink-700' }`}>Précédent</button>
            <span className="text-sm text-pink-700 px-3 py-1 bg-white rounded-lg border border-pink-300">{filters.page || 1}</span>
            <button onClick={() => setFilters(f => ({ ...f, page: (f.page || 1) + 1 }))} disabled={(appointments.length || 0) < (filters.limit || 25)} className={`px-3 py-1 rounded-lg border transition-colors ${ (appointments.length || 0) < (filters.limit || 25) ? 'bg-gray-100 text-gray-400 border-gray-200' : 'bg-white hover:bg-pink-50 border-pink-300 text-pink-700' }`}>Suivant</button>
          </div>
        </div>
      </div>

      {/* Modal création */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl rounded-xl shadow-2xl border-2 border-pink-200 bg-white">
            <div className="px-6 py-4 border-b-2 border-pink-200 bg-pink-50 rounded-t-xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-rounded text-pink-600">event_available</span>
                <h3 className="text-lg font-semibold text-pink-800">Nouveau Rendez-vous</h3>
              </div>
              <button onClick={() => setShowCreate(false)} className="text-pink-500 hover:text-pink-700 rounded-full p-1 hover:bg-pink-100" aria-label="Fermer">
                <span className="material-symbols-rounded">close</span>
                </button>
              </div>
            <form onSubmit={createAppointment} className="px-6 py-5 space-y-5">
              {createError && (
                <div className="bg-red-100 border border-red-300 text-red-800 px-4 py-2 rounded">{createError}</div>
              )}
              <div>
                <label className="block text-sm font-medium text-pink-800 mb-1">Patient</label>
                <select value={newAppt.patient} onChange={(e) => setNewAppt(a => ({ ...a, patient: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50">
                  <option value="">— Sélectionner —</option>
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.prenom} {p.nom}</option>
                  ))}
                </select>
            </div>
              <div>
                <label className="block text-sm font-medium text-pink-800 mb-1">Médecin</label>
                <select value={newAppt.medecin} onChange={(e) => setNewAppt(a => ({ ...a, medecin: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50">
                  <option value="">— Sélectionner —</option>
                  {medecins.map(m => (
                    <option key={m.id} value={m.id}>{(() => { const spec = m?.specialite?.label || m?.specialite?.nom || m?.specialite || m?.specialty?.name || m?.specialty || ''; return `Dr. ${m.prenom || ''} ${m.nom || ''}${spec ? ' — ' + spec : ''}`; })()}</option>
                  ))}
                </select>
                            </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Date</label>
                  <input type="date" value={newAppt.date} onChange={(e) => setNewAppt(a => ({ ...a, date: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" required />
                              </div>
                <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Heure</label>
                  <input type="time" value={newAppt.heure} onChange={(e) => setNewAppt(a => ({ ...a, heure: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" required />
                                </div>
                                </div>
              <div>
                <label className="block text-sm font-medium text-pink-800 mb-1">Motif</label>
                <select value={newAppt.motif} onChange={(e) => setNewAppt(a => ({ ...a, motif: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" required>
                  <option value="">Sélectionner</option>
                  <option value="consultation">Consultation générale</option>
                  <option value="suivi">Suivi</option>
                  <option value="urgence">Urgence</option>
                  <option value="controle">Contrôle</option>
                  <option value="specialiste">Spécialiste</option>
                </select>
                            </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Durée (min)</label>
                  <select value={newAppt.duree} onChange={(e) => setNewAppt(a => ({ ...a, duree: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50">
                    <option value="15">15</option>
                    <option value="30">30</option>
                    <option value="45">45</option>
                    <option value="60">60</option>
                  </select>
                          </div>
                <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Notes</label>
                  <input type="text" value={newAppt.notes} onChange={(e) => setNewAppt(a => ({ ...a, notes: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" />
                        </div>
                    </div>
              <div className="flex justify-end gap-2 pt-4 border-t-2 border-pink-200">
                <button type="button" onClick={() => setShowCreate(false)} className="px-4 py-2 rounded-lg border-2 border-pink-300 text-pink-700 hover:bg-pink-50 hover:border-pink-400 transition-colors font-medium">Annuler</button>
                <button type="submit" disabled={loading} className="px-4 py-2 rounded-lg bg-pink-600 text-white hover:bg-pink-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium shadow-lg hover:shadow-xl transition-colors">
                  {loading ? 'Création…' : 'Créer le RDV'}
                </button>
                        </div>
            </form>
                      </div>
                    </div>
                  )}

      {/* Modal édition */}
      {showEdit && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl rounded-xl shadow-2xl border-2 border-pink-200 bg-white">
            <div className="px-6 py-4 border-b-2 border-pink-200 bg-pink-50 rounded-t-xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-rounded text-pink-600">edit_calendar</span>
                <h3 className="text-lg font-semibold text-pink-800">Modifier le Rendez-vous</h3>
                </div>
              <button onClick={() => setShowEdit(false)} className="text-pink-500 hover:text-pink-700 rounded-full p-1 hover:bg-pink-100" aria-label="Fermer">
                <span className="material-symbols-rounded">close</span>
              </button>
                </div>
            <form onSubmit={submitEdit} className="px-6 py-5 space-y-5">
              {editError && (
                <div className="bg-red-100 border border-red-300 text-red-800 px-4 py-2 rounded">{editError}</div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Date</label>
                  <input type="date" value={editAppt.date} onChange={(e) => setEditAppt(a => ({ ...a, date: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Heure</label>
                  <input type="time" value={editAppt.heure} onChange={(e) => setEditAppt(a => ({ ...a, heure: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" required />
                </div>
              </div>
                <div>
                <label className="block text-sm font-medium text-pink-800 mb-1">Motif</label>
                <select value={editAppt.motif} onChange={(e) => setEditAppt(a => ({ ...a, motif: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" required>
                  <option value="">Sélectionner</option>
                    <option value="consultation">Consultation générale</option>
                  <option value="suivi">Suivi</option>
                    <option value="urgence">Urgence</option>
                  <option value="controle">Contrôle</option>
                    <option value="specialiste">Spécialiste</option>
                  </select>
                </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Durée (min)</label>
                  <select value={editAppt.duree} onChange={(e) => setEditAppt(a => ({ ...a, duree: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50">
                    <option value="15">15</option>
                    <option value="30">30</option>
                    <option value="45">45</option>
                    <option value="60">60</option>
                  </select>
              </div>
              <div>
                  <label className="block text-sm font-medium text-pink-800 mb-1">Notes</label>
                  <input type="text" value={editAppt.notes} onChange={(e) => setEditAppt(a => ({ ...a, notes: e.target.value }))} className="w-full border border-pink-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-400 bg-pink-50" />
              </div>
              </div>
              <div className="flex justify-end gap-2 pt-4 border-t-2 border-pink-200">
                <button type="button" onClick={() => setShowEdit(false)} className="px-4 py-2 rounded-lg border-2 border-pink-300 text-pink-700 hover:bg-pink-50 hover:border-pink-400 transition-colors font-medium">Annuler</button>
                <button type="submit" disabled={loading} className="px-4 py-2 rounded-lg bg-pink-600 text-white hover:bg-pink-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium shadow-lg hover:shadow-xl transition-colors">
                  {loading ? 'Enregistrement…' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* (Section RDV des patients retirée) */}
    </div>
  );
};

export default Appointments;



