// src/_services/audit.service.ts
import Axios from "./caller.service";
import type { AxiosResponse } from "axios";
import { unwrapList, safeGetList, safeGetObject, enc } from './service.utils';
import { buildAuditParams, UIAuditFilters } from "./query/audit.query";

// Types pour l'audit
export interface AuditLog {
  id: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'LOGOUT' | 'API_REQUEST';
  entityType: string;
  entityId?: string;
  ip?: string;
  createdAt: string;
  user?: {
    id: string;
    email: string;
    prenom: string;
    nom: string;
  };
  payload?: {
    before?: any;
    after?: any;
    description?: string;
    metadata?: {
      http_method?: string;
      url?: string;
      status_code?: number;
      request_size?: number;
      response_size?: number;
      ip_address?: string;
      user_agent?: string;
      request_uri?: string;
      referer?: string;
      session_id?: string;
    };
  };
}

export interface AuditStatistics {
  users: Array<{
    id: string;
    prenom: string;
    nom: string;
    email: string;
    total_actions: number;
  }>;
  actions: Array<{
    action: string;
    count: number;
  }>;
  entities: Array<{
    entity_type: string;
    count: number;
  }>;
}

const auditService = {
  // ===== Collection / Item REST standards =====
  getAuditLogs(filters: UIAuditFilters = {}): Promise<AuditLog[]> {
    const params = buildAuditParams(filters);
    return safeGetList<AuditLog>(Axios.get(`audit?${params.toString()}`));
  },

  getOneAuditLog(id: string | number): Promise<AuditLog> {
    return safeGetObject<AuditLog>(Axios.get(`audit/${enc(id)}`));
  },

  // ===== Statistiques =====
  getStatisticsByUser(filters: Record<string, any> = {}): Promise<AuditStatistics['users']> {
    return safeGetList(Axios.get("audit/statistics/users", { params: filters }));
  },

  getStatisticsByAction(filters: Record<string, any> = {}): Promise<AuditStatistics['actions']> {
    return safeGetList(Axios.get("audit/statistics/actions", { params: filters }));
  },

  getStatisticsByEntity(filters: Record<string, any> = {}): Promise<AuditStatistics['entities']> {
    return safeGetList(Axios.get("audit/statistics/entities", { params: filters }));
  },

  getStatisticsByPeriod(period: string = 'day', filters: Record<string, any> = {}): Promise<any> {
    return safeGetObject(Axios.get("audit/statistics/period", { 
      params: { period, ...filters } 
    }));
  },

  // ===== Actions spécifiques =====
  getRecentActionsByUser(userId: string, limit: number = 20): Promise<AuditLog[]> {
    return safeGetList<AuditLog>(Axios.get(`audit/user/${enc(userId)}/recent`, {
      params: { limit }
    }));
  },

  getAuditTrailForEntity(entityType: string, entityId: string, limit: number = 50): Promise<AuditLog[]> {
    return safeGetList<AuditLog>(Axios.get(`audit/entity/${enc(entityType)}/${enc(entityId)}`, {
      params: { limit }
    }));
  },

  getAvailableFilters(): Promise<any> {
    return safeGetObject(Axios.get("audit/filters"));
  },

  // ===== Méthodes pour le Dashboard =====
  getRecentActivities(userId: string, limit: number = 5): Promise<AuditLog[]> {
    return this.getRecentActionsByUser(userId, limit);
  },

  getStagiaireStats(userId: string): Promise<any> {
    return safeGetObject(Axios.get(`/audit/stagiaire/${enc(userId)}/stats`));
  },

  // ===== Utilitaires =====
  getActionLabel(action: string): string {
    const labels = {
      'CREATE': 'Création',
      'UPDATE': 'Modification',
      'DELETE': 'Suppression',
      'LOGIN': 'Connexion',
      'LOGOUT': 'Déconnexion',
      'API_REQUEST': 'Requête API'
    };
    return labels[action as keyof typeof labels] || action;
  },

  getActionColor(action: string): string {
    const colors = {
      'CREATE': 'green',
      'UPDATE': 'blue',
      'DELETE': 'red',
      'LOGIN': 'purple',
      'LOGOUT': 'orange',
      'API_REQUEST': 'gray'
    };
    return colors[action as keyof typeof colors] || 'gray';
  },

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleString('fr-FR');
  },

  formatEntityType(entityType: string): string {
    return entityType.split('\\').pop() || entityType;
  }
};

export default auditService;