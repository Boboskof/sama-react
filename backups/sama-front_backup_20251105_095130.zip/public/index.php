<?php
// Fichier temporaire pour éviter l'erreur du serveur web
// Ce fichier redirige vers l'application React

header('Location: http://localhost:5173');
exit();
?>

