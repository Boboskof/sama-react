import React, { useState, useRef, useEffect } from 'react';
import { useSearch } from '../hooks/useSearch';

const SearchBar = ({ 
  category = null, 
  placeholder = "Rechercher...", 
  onResultSelect = null,
  showQuickResults = true,
  className = ""
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef(null);
  const resultsRef = useRef(null);

  const { 
    query, 
    setQuery, 
    results, 
    loading, 
    error, 
    quickSearch 
  } = useSearch(category, { limit: 10 });

  // Recherche rapide pour autocomplétion
  useEffect(() => {
    if (query && showQuickResults) {
      quickSearch(query);
    }
  }, [query, quickSearch, showQuickResults]);

  const handleInputChange = (e) => {
    setQuery(e.target.value);
    setIsOpen(true);
    setSelectedIndex(-1);
  };

  const handleKeyDown = (e) => {
    if (!isOpen || results.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < results.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && results[selectedIndex]) {
          handleResultSelect(results[selectedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        inputRef.current?.blur();
        break;
    }
  };

  const handleResultSelect = (result) => {
    if (onResultSelect) {
      onResultSelect(result);
    }
    setIsOpen(false);
    setQuery('');
  };

  const getResultLabel = (result) => {
    switch (result.type) {
      case 'patient':
        return `${result.metadata?.patient_name || 'Patient inconnu'}`;
      case 'rendez_vous':
        return `${result.metadata?.patient_name || 'Patient'} - ${result.metadata?.created_at || ''}`;
      case 'document':
        return `${result.metadata?.patient_name || 'Patient'} - ${result.title}`;
      case 'communication':
        return `${result.metadata?.patient_name || 'Patient'} - ${result.title}`;
      default:
        return result.title || result.subtitle || 'Résultat';
    }
  };

  const getResultIcon = (result) => {
    switch (result.type) {
      case 'patient': return '👤';
      case 'rendez_vous': return '📅';
      case 'document': return '📄';
      case 'communication': return '💬';
      default: return '🔍';
    }
  };

  return (
    <div className={`relative ${className}`}>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        {loading && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
          </div>
        )}
      </div>

      {isOpen && (query.length >= 2) && (
        <div 
          ref={resultsRef}
          className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-96 overflow-y-auto"
        >
          {error ? (
            <div className="p-3 text-red-600 text-sm">
              {error}
            </div>
          ) : results.length > 0 ? (
            <div className="py-1">
              {results.map((result, index) => (
                <button
                  key={`${result.type}-${result.id}`}
                  onClick={() => handleResultSelect(result)}
                  className={`w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center space-x-3 ${
                    index === selectedIndex ? 'bg-blue-50' : ''
                  }`}
                >
                  <span className="text-lg">{getResultIcon(result)}</span>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-900 truncate">
                      {getResultLabel(result)}
                    </div>
                    {result.subtitle && (
                      <div className="text-sm text-gray-500 truncate">
                        {result.subtitle}
                      </div>
                    )}
                  </div>
                  <div className="text-xs text-gray-400">
                    {result.type}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="p-3 text-gray-500 text-sm">
              Aucun résultat trouvé
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchBar;
